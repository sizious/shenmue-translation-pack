#ifndef __VERSION_H__
#define __VERSION_H__

#define AUDACIOUSVGMSTREAM_VERSION "1.0.0"

#endif
