#!/bin/sh
DIR="`dirname "$0"`"
#VERSION="`svnversion "$DIR" | tr : _`"
VERSION="717"
echo "r$VERSION"
