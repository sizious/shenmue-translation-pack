VGM Stream r1015 / 20131118
---

Patched version of the 20131118 SVN release 1015 by the SiZiOUS of the Shentrad 
team.

This patched version was made to compile the vgmstream logic in standalone mode.
  - SVN client don't need to be installed
  - The makefile.mingw file in the "test" directory was fixed
Everything else is in their original form.

To build the "test.exe" command line decoder program:
  1. Make sure you have MSYS and MinGW installed
  2. Check if your PATH environment variable is pointing out on the MSYS and 
     MinGW "bin" directories.
  3. Double-click on the "build.cmd" script located in this directory and 
     wait.
  4. You should have the "vgmstrm.exe" binary ready to use for ADPCM Streaming
     Toolkit. Enjoy !

Official Site: http://hcs64.com/vgmstream.html

- eof -
