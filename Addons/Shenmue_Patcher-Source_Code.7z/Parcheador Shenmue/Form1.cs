﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Media;
using System.Windows.Forms;
using ICSharpCode.SharpZipLib.Zip;


namespace Parcheador_Shenmue
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string[] GDI;
        string[] GDIFolder;
        string[] TracksGDI1;
        string[] TracksGDI2;
        string[] TracksGDI3;
        string[] TracksGDI4;

        string DirSep;

        string AppPath;
        string TempPath;
        string UtilsPath;
        string tmpZip;

        string PatchPath;
        string PatchPath1;
        string PatchPath2;
        string PatchPath3;
        string PatchPath4;

        string GDI1Path;
        string GDI2Path;
        string GDI3Path;
        string GDI4Path;
        string IPPath;

        string FinalISOPath;
        string FinalISO1;
        string FinalISO2;
        string FinalISO3;
        string FinalISO4;

        string PatchPathCommon;

        int ProgressMax;
        int IdiomaSeleccionado;

        bool Parcheando = false;

        StreamWriter LogStream;

        //string logText = "";

        #region Controles

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Advertencia: Este parcheador va a tardar un buen rato en hacer su trabajo. Vete a tomar un bocadillo o algo.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            Parcheando = true;
            EnableControls(false);
            LogStream = new StreamWriter(AppPath + "log.txt");

            ProgressMax = 0;

            if (textBox1.Text != string.Empty) ProgressMax += 9;
            if (textBox2.Text != string.Empty) ProgressMax += 9;
            if (textBox3.Text != string.Empty) ProgressMax += 9;
            if (textBox4.Text != string.Empty) ProgressMax += 14;

            Progress.Value = 0;
            Progress.Maximum = ProgressMax;

            Parcheo.RunWorkerAsync();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ODlg.FileName = "";
            ODlg.Filter = "Archivos GDI (*.gdi)|*.gdi|Todos los archivos (*.*)|*.*";
            if (ODlg.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            textBox1.Text = ODlg.FileName;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ODlg.FileName = "";
            ODlg.Filter = "Archivos GDI (*.gdi)|*.gdi|Todos los archivos (*.*)|*.*";
            if (ODlg.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            textBox2.Text = ODlg.FileName;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ODlg.FileName = "";
            ODlg.Filter = "Archivos GDI (*.gdi)|*.gdi|Todos los archivos (*.*)|*.*";
            if (ODlg.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            textBox3.Text = ODlg.FileName;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ODlg.FileName = "";
            ODlg.Filter = "Archivos GDI (*.gdi)|*.gdi|Todos los archivos (*.*)|*.*";
            if (ODlg.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            textBox4.Text = ODlg.FileName;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DirSep = Path.DirectorySeparatorChar.ToString();

            AppPath = Path.GetDirectoryName(Application.ExecutablePath) + DirSep;
            TempPath = Path.GetTempPath() + "ShenmueESP" + DirSep;
            tmpZip = Path.GetTempPath() + "ShenmueESP.zip";

            UtilsPath = TempPath + "Utilidades" + DirSep;
            PatchPath = TempPath + "Parche" + DirSep;

            PatchPath1 = PatchPath + "1" + DirSep;
            PatchPath2 = PatchPath + "2" + DirSep;
            PatchPath3 = PatchPath + "3" + DirSep;
            PatchPath4 = PatchPath + "4" + DirSep;
            PatchPathCommon = PatchPath + "common" + DirSep;

            GDI1Path = TempPath + "GDI1" + DirSep;
            GDI2Path = TempPath + "GDI2" + DirSep;
            GDI3Path = TempPath + "GDI3" + DirSep;
            GDI4Path = TempPath + "GDI4" + DirSep;

            IPPath = TempPath + "IPs" + DirSep;

            FinalISOPath = AppPath + "Shenmue en español" + DirSep;
            FinalISO1 = FinalISOPath + "Shenmue (Disco 1)";
            FinalISO2 = FinalISOPath + "Shenmue (Disco 2)";
            FinalISO3 = FinalISOPath + "Shenmue (Disco 3)";
            FinalISO4 = FinalISOPath + "Shenmue (Disco 4)";

            comboBox1.SelectedIndex = 0;
            IdiomaSeleccionado = 0;

            if(Environment.OSVersion.Platform == PlatformID.Unix) MessageBox.Show("Este programa en principio está preparado para funcionar en Linux, pero no ha sido testeado al 100% y puede dar problemas.\n\nPara poder parchear es indispensable tener instalados estos programas:\n\n  - Wine\n  - cdrtools (concretamente, de este paquete, se necesita el mkisofs, y tiene\n     que ser una versión compilada con el \"-duplicates-once\" activado).\n\nEn otras palabras, te será seguramente mucho más fácil bajarte una ISO de Windows e instalarla en VirtualBox.");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && textBox4.Text == "") button1.Enabled = false;
            else button1.Enabled = true;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && textBox4.Text == "") button1.Enabled = false;
            else button1.Enabled = true;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && textBox4.Text == "") button1.Enabled = false;
            else button1.Enabled = true;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && textBox4.Text == "") button1.Enabled = false;
            else button1.Enabled = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            IdiomaSeleccionado = comboBox1.SelectedIndex;
        }

        void EnableControls(bool enabled)
        {
            button1.Enabled = enabled;
            button2.Enabled = enabled;
            button3.Enabled = enabled;
            button4.Enabled = enabled;
            button5.Enabled = enabled;

            textBox1.Enabled = enabled;
            textBox2.Enabled = enabled;
            textBox3.Enabled = enabled;
            textBox4.Enabled = enabled;

            label1.Enabled = enabled;
            label2.Enabled = enabled;
            label3.Enabled = enabled;
            label4.Enabled = enabled;
            label5.Enabled = enabled;

            comboBox1.Enabled = enabled;
            groupBox1.Enabled = enabled;
        }

        #endregion

        private void Parcheo_DoWork(object sender, DoWorkEventArgs e)
        {
#if !DEBUG
            try
            {
#endif
                int Progress = 0;

                GDI = new string[] { textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text };
                GDIFolder = new string[4];
                for (int n = 0; n < 4; n++)
                {
                    if (GDI[n] != String.Empty) GDIFolder[n] = Path.GetDirectoryName(GDI[n]) + DirSep;
                    else GDIFolder[n] = String.Empty;
                }

                #region Comprobar existencia de archivos

                Parcheo.ReportProgress(Progress++, "Comprobando la existencia de los archivos necesarios...");

                //Comprobar si los GDIs introducidos existen
                for (int n = 0; n < 4; n++)
                {
                    if (File.Exists(GDI[n]) == false && GDI[n] != String.Empty)
                    {
                        MessageBox.Show("El archivo " + GDI[n] + " no existe.\n\nEl parcheador no puede continuar.", "Archivo no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Parcheo.ReportProgress(0, "En espera...");
                        return;
                    }
                }

                //Tracks del disco 1
                if (GDI[0] != String.Empty)
                {
                    TracksGDI1 = ReadTracksNames(GDI[0]);

                    for (int n = 0; n < TracksGDI1.Length; n++)
                    {
                        if (File.Exists(TracksGDI1[n]) == false)
                        {
                            MessageBox.Show("No se ha encontrado el archivo \"" + TracksGDI1[n] + "\".\n\nAsegúrate de que las " + TracksGDI1.Length + " pistas del disco están en la misma carpeta que el archivo *.gdi, en este caso:\n\n" + GDI[0], "Archivo no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Parcheo.ReportProgress(0, "En espera...");
                            return;
                        }
                    }
                }

                //Tracks del disco 2
                if (GDI[1] != String.Empty)
                {
                    TracksGDI2 = ReadTracksNames(GDI[1]);

                    for (int n = 0; n < TracksGDI2.Length; n++)
                    {
                        if (File.Exists(TracksGDI2[n]) == false)
                        {
                            MessageBox.Show("No se ha encontrado el archivo \"" + TracksGDI2[n] + "\".\n\nAsegúrate de que las " + TracksGDI2.Length + " pistas del disco están en la misma carpeta que el archivo *.gdi, en este caso:\n\n" + GDI[1], "Archivo no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Parcheo.ReportProgress(0, "En espera...");
                            return;
                        }
                    }
                }

                //Tracks del disco 3
                if (GDI[2] != String.Empty)
                {
                    TracksGDI3 = ReadTracksNames(GDI[2]);

                    for (int n = 0; n < TracksGDI3.Length; n++)
                    {
                        if (File.Exists(TracksGDI3[n]) == false)
                        {
                            MessageBox.Show("No se ha encontrado el archivo \"" + TracksGDI3[n] + "\".\n\nAsegúrate de que las " + TracksGDI3.Length + " pistas del disco están en la misma carpeta que el archivo *.gdi, en este caso:\n\n" + GDI[2], "Archivo no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Parcheo.ReportProgress(0, "En espera...");
                            return;
                        }
                    }
                }

                //Tracks del disco 4
                if (GDI[3] != String.Empty)
                {
                    TracksGDI4 = ReadTracksNames(GDI[3]);

                    for (int n = 0; n < TracksGDI4.Length; n++)
                    {
                        if (File.Exists(TracksGDI4[n]) == false)
                        {
                            MessageBox.Show("No se ha encontrado el archivo \"" + TracksGDI4[n] + "\".\n\nAsegúrate de que las " + TracksGDI4.Length + " pistas del disco están en la misma carpeta que el archivo *.gdi, en este caso:\n\n" + GDI[3], "Archivo no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Parcheo.ReportProgress(0, "En espera...");
                            return;
                        }
                    }
                }

                #endregion

                #region Extraer archivos necesarios del parcheador

                //Stream zip = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Parcheador_Shenmue.ShenmueESP.zip");
                //Descomprimir(zip, Path.GetTempPath());
                //zip.Close();

                DecompressFileLZMA("Parcheador_Shenmue.data", tmpZip);
                FileStream zip = new FileStream(tmpZip, FileMode.Open, FileAccess.Read);
                Descomprimir(zip, Path.GetTempPath());
                zip.Close();

                if (File.Exists(tmpZip)) File.Delete(tmpZip);

                #endregion

                #region Extraer GDIs

                if (Directory.Exists(GDI1Path) == true) Directory.Delete(GDI1Path, true);
                if (Directory.Exists(GDI2Path) == true) Directory.Delete(GDI2Path, true);
                if (Directory.Exists(GDI3Path) == true) Directory.Delete(GDI3Path, true);
                if (Directory.Exists(GDI4Path) == true) Directory.Delete(GDI4Path, true);

                if (Directory.Exists(IPPath) == true) Directory.Delete(IPPath, true);

                Directory.CreateDirectory(GDI1Path);
                Directory.CreateDirectory(GDI2Path);
                Directory.CreateDirectory(GDI3Path);
                Directory.CreateDirectory(GDI4Path);

                Directory.CreateDirectory(IPPath);

                if (GDI[0] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Convirtiendo tracks del GDI nº1 a *.iso...");

                    int LBA = ReadLBA(GDI[0]);

                    if (StartProcess(UtilsPath + "bin2iso.exe", "\"" + TracksGDI1[2] + "\" \"" + GDI1Path + Path.GetFileNameWithoutExtension(TracksGDI1[2]) + ".iso\"", "", true) != 0) return;
                    if (StartProcess(UtilsPath + "bin2iso.exe", "\"" + TracksGDI1[5] + "\" \"" + GDI1Path + Path.GetFileNameWithoutExtension(TracksGDI1[5]) + ".iso\"", "", true) != 0) return;

                    if (File.Exists(GDI1Path + Path.GetFileNameWithoutExtension(TracksGDI1[2]) + ".iso") == false || File.Exists(GDI1Path + Path.GetFileNameWithoutExtension(TracksGDI1[5]) + ".iso") == false)
                    {
                        MessageBox.Show("Ha habido un problema al convertir las pistas del GDI nº1 a *.iso.\n\nEl parcheador no puede continuar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Parcheo.ReportProgress(0, "En espera...");
                        return;
                    }

                    Parcheo.ReportProgress(Progress++, "Extrayendo GDI nº1...");

                    if (StartProcess(UtilsPath + "extract.exe", "\"" + GDI1Path + Path.GetFileNameWithoutExtension(TracksGDI1[2]) + ".iso\" \"" + GDI1Path + Path.GetFileNameWithoutExtension(TracksGDI1[5]) + ".iso\" " + LBA.ToString(), GDI1Path) != 0) return;

                    File.Delete(GDI1Path + Path.GetFileNameWithoutExtension(TracksGDI1[2]) + ".iso");
                    File.Delete(GDI1Path + Path.GetFileNameWithoutExtension(TracksGDI1[5]) + ".iso");

                    File.Move(GDI1Path + "IP.BIN", IPPath + "IP1.BIN");
                }

                if (GDI[1] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Convirtiendo tracks del GDI nº2 a *.iso...");

                    int LBA = ReadLBA(GDI[1]);

                    if (StartProcess(UtilsPath + "bin2iso.exe", "\"" + TracksGDI2[2] + "\" \"" + GDI2Path + Path.GetFileNameWithoutExtension(TracksGDI2[2]) + ".iso\"", "", true) != 0) return;
                    if (StartProcess(UtilsPath + "bin2iso.exe", "\"" + TracksGDI2[5] + "\" \"" + GDI2Path + Path.GetFileNameWithoutExtension(TracksGDI2[5]) + ".iso\"", "", true) != 0) return;

                    if (File.Exists(GDI2Path + Path.GetFileNameWithoutExtension(TracksGDI2[2]) + ".iso") == false || File.Exists(GDI2Path + Path.GetFileNameWithoutExtension(TracksGDI2[5]) + ".iso") == false)
                    {
                        MessageBox.Show("Ha habido un problema al convertir las pistas del GDI nº2 a *.iso.\n\nEl parcheador no puede continuar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Parcheo.ReportProgress(0, "En espera...");
                        return;
                    }

                    Parcheo.ReportProgress(Progress++, "Extrayendo GDI nº2...");

                    if (StartProcess(UtilsPath + "extract.exe", "\"" + GDI2Path + Path.GetFileNameWithoutExtension(TracksGDI2[2]) + ".iso\" \"" + GDI2Path + Path.GetFileNameWithoutExtension(TracksGDI2[5]) + ".iso\" " + LBA.ToString(), GDI2Path) != 0) return;

                    File.Delete(GDI2Path + Path.GetFileNameWithoutExtension(TracksGDI2[2]) + ".iso");
                    File.Delete(GDI2Path + Path.GetFileNameWithoutExtension(TracksGDI2[5]) + ".iso");

                    File.Move(GDI2Path + "IP.BIN", IPPath + "IP2.BIN");
                }

                if (GDI[2] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Convirtiendo tracks del GDI nº3 a *.iso...");

                    int LBA = ReadLBA(GDI[2]);

                    if (StartProcess(UtilsPath + "bin2iso.exe", "\"" + TracksGDI3[2] + "\" \"" + GDI3Path + Path.GetFileNameWithoutExtension(TracksGDI3[2]) + ".iso\"", "", true) != 0) return;
                    if (StartProcess(UtilsPath + "bin2iso.exe", "\"" + TracksGDI3[5] + "\" \"" + GDI3Path + Path.GetFileNameWithoutExtension(TracksGDI3[5]) + ".iso\"", "", true) != 0) return;

                    if (File.Exists(GDI3Path + Path.GetFileNameWithoutExtension(TracksGDI3[2]) + ".iso") == false || File.Exists(GDI3Path + Path.GetFileNameWithoutExtension(TracksGDI3[5]) + ".iso") == false)
                    {
                        MessageBox.Show("Ha habido un problema al convertir las pistas del GDI nº3 a *.iso.\n\nEl parcheador no puede continuar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Parcheo.ReportProgress(0, "En espera...");
                        return;
                    }

                    Parcheo.ReportProgress(Progress++, "Extrayendo GDI nº3...");

                    if (StartProcess(UtilsPath + "extract.exe", "\"" + GDI3Path + Path.GetFileNameWithoutExtension(TracksGDI3[2]) + ".iso\" \"" + GDI3Path + Path.GetFileNameWithoutExtension(TracksGDI3[5]) + ".iso\" " + LBA.ToString(), GDI3Path) != 0) return;

                    File.Delete(GDI3Path + Path.GetFileNameWithoutExtension(TracksGDI3[2]) + ".iso");
                    File.Delete(GDI3Path + Path.GetFileNameWithoutExtension(TracksGDI3[5]) + ".iso");

                    File.Move(GDI3Path + "IP.BIN", IPPath + "IP3.BIN");
                }

                if (GDI[3] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Convirtiendo tracks del GDI nº4 a *.iso...");

                    int LBA = ReadLBA(GDI[3]);

                    if (StartProcess(UtilsPath + "bin2iso.exe", "\"" + TracksGDI4[2] + "\" \"" + GDI4Path + Path.GetFileNameWithoutExtension(TracksGDI4[2]) + ".iso\"", "", true) != 0) return;
                    if (StartProcess(UtilsPath + "bin2iso.exe", "\"" + TracksGDI4[6] + "\" \"" + GDI4Path + Path.GetFileNameWithoutExtension(TracksGDI4[6]) + ".iso\"", "", true) != 0) return;

                    if (File.Exists(GDI4Path + Path.GetFileNameWithoutExtension(TracksGDI4[2]) + ".iso") == false || File.Exists(GDI4Path + Path.GetFileNameWithoutExtension(TracksGDI4[6]) + ".iso") == false)
                    {
                        MessageBox.Show("Ha habido un problema al convertir las pistas del GDI nº4 a *.iso.\n\nEl parcheador no puede continuar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Parcheo.ReportProgress(0, "En espera...");
                        return;
                    }

                    Parcheo.ReportProgress(Progress++, "Extrayendo GDI nº4...");

                    if (StartProcess(UtilsPath + "extract.exe", "\"" + GDI4Path + Path.GetFileNameWithoutExtension(TracksGDI4[2]) + ".iso\" \"" + GDI4Path + Path.GetFileNameWithoutExtension(TracksGDI4[6]) + ".iso\" " + LBA.ToString(), GDI4Path) != 0) return;

                    File.Delete(GDI4Path + Path.GetFileNameWithoutExtension(TracksGDI4[2]) + ".iso");
                    File.Delete(GDI4Path + Path.GetFileNameWithoutExtension(TracksGDI4[6]) + ".iso");

                    File.Move(GDI4Path + "IP.BIN", IPPath + "IP4.BIN");
                }

                #endregion

                #region Parcheo XDeltas

                Parcheo.ReportProgress(Progress++, "Parcheando XDeltas...");

                //Disco 1
                if (GDI[0] != String.Empty)
                {
                    if (StartProcess(UtilsPath + "xdelta.exe", "-d -s \"" + GDI1Path + "1ST_READ.BIN\" \"" + PatchPath1 + "EXE.DELTA\" \"" + GDI1Path + "1ST_READ.BIN2\"", "", true) != 0) return;
                    if (StartProcess(UtilsPath + "xdelta.exe", "-d -s \"" + IPPath + "IP1.BIN\" \"" + PatchPath1 + "IP.DELTA\" \"" + IPPath + "IP1.BIN2\"", "", true) != 0) return;

                    File.Delete(GDI1Path + "1ST_READ.BIN");
                    File.Move(GDI1Path + "1ST_READ.BIN2", GDI1Path + "1ST_READ.BIN");

                    File.Delete(IPPath + "IP1.BIN");
                    File.Move(IPPath + "IP1.BIN2", IPPath + "IP1.BIN");
                }

                //Disco 2
                if (GDI[1] != String.Empty)
                {
                    if (StartProcess(UtilsPath + "xdelta.exe", "-d -s \"" + GDI2Path + "1ST_READ.BIN\" \"" + PatchPath2 + "EXE.DELTA\" \"" + GDI2Path + "1ST_READ.BIN2\"", "", true) != 0) return;
                    if (StartProcess(UtilsPath + "xdelta.exe", "-d -s \"" + IPPath + "IP2.BIN\" \"" + PatchPath2 + "IP.DELTA\" \"" + IPPath + "IP2.BIN2\"", "", true) != 0) return;

                    File.Delete(GDI2Path + "1ST_READ.BIN");
                    File.Move(GDI2Path + "1ST_READ.BIN2", GDI2Path + "1ST_READ.BIN");

                    File.Delete(IPPath + "IP2.BIN");
                    File.Move(IPPath + "IP2.BIN2", IPPath + "IP2.BIN");
                }

                //Disco 3
                if (GDI[2] != String.Empty)
                {
                    if (StartProcess(UtilsPath + "xdelta.exe", "-d -s \"" + GDI3Path + "1ST_READ.BIN\" \"" + PatchPath3 + "EXE.DELTA\" \"" + GDI3Path + "1ST_READ.BIN2\"", "", true) != 0) return;
                    if (StartProcess(UtilsPath + "xdelta.exe", "-d -s \"" + IPPath + "IP3.BIN\" \"" + PatchPath3 + "IP.DELTA\" \"" + IPPath + "IP3.BIN2\"", "", true) != 0) return;

                    File.Delete(GDI3Path + "1ST_READ.BIN");
                    File.Move(GDI3Path + "1ST_READ.BIN2", GDI3Path + "1ST_READ.BIN");

                    File.Delete(IPPath + "IP3.BIN");
                    File.Move(IPPath + "IP3.BIN2", IPPath + "IP3.BIN");
                }

                //Disco 4
                if (GDI[3] != String.Empty)
                {
                    if (StartProcess(UtilsPath + "xdelta.exe", "-d -s \"" + GDI4Path + "1ST_READ.BIN\" \"" + PatchPath4 + "EXE.DELTA\" \"" + GDI4Path + "1ST_READ.BIN2\"", "", true) != 0) return;
                    if (StartProcess(UtilsPath + "xdelta.exe", "-d -s \"" + IPPath + "IP4.BIN\" \"" + PatchPath4 + "IP.DELTA\" \"" + IPPath + "IP4.BIN2\"", "", true) != 0) return;
                    if (StartProcess(UtilsPath + "xdelta.exe", "-d -s \"" + GDI4Path + "MOVIE.BIN\" \"" + PatchPath4 + "MOVIE.DELTA\" \"" + GDI4Path + "MOVIE.BIN2\"", "", true) != 0) return;
                    if (StartProcess(UtilsPath + "xdelta.exe", "-d -s \"" + GDI4Path + "RPG.BIN\" \"" + PatchPath4 + "RPG.DELTA\" \"" + GDI4Path + "RPG.BIN2\"", "", true) != 0) return;

                    File.Delete(GDI4Path + "1ST_READ.BIN");
                    File.Move(GDI4Path + "1ST_READ.BIN2", GDI4Path + "1ST_READ.BIN");

                    File.Delete(IPPath + "IP4.BIN");
                    File.Move(IPPath + "IP4.BIN2", IPPath + "IP4.BIN");

                    File.Delete(GDI4Path + "MOVIE.BIN");
                    File.Move(GDI4Path + "MOVIE.BIN2", GDI4Path + "MOVIE.BIN");

                    File.Delete(GDI4Path + "RPG.BIN");
                    File.Move(GDI4Path + "RPG.BIN2", GDI4Path + "RPG.BIN");
                }

                #endregion

                #region Reemplazo de archivos

                //Disco 1
                if (GDI[0] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Reemplazando archivos del disco nº1...");

                    CopyFolder(PatchPath1 + "SCENE" + DirSep + "01" + DirSep + "D000", GDI1Path + "SCENE" + DirSep + "01" + DirSep + "D000", true);
                    CopyFolder(PatchPath1 + "SCENE" + DirSep + "01" + DirSep + "DBYO", GDI1Path + "SCENE" + DirSep + "01" + DirSep + "DBYO", true);
                    CopyFolder(PatchPath1 + "SCENE" + DirSep + "01" + DirSep + "JD00", GDI1Path + "SCENE" + DirSep + "01" + DirSep + "JD00", true);
                    CopyFolder(PatchPath1 + "SCENE" + DirSep + "01" + DirSep + "JOMO", GDI1Path + "SCENE" + DirSep + "01" + DirSep + "JOMO", true);

                    //Archivos comunes a los 3 primeros CDs
                    CopyFolder(PatchPathCommon + "MISC", GDI1Path + "MISC", true);
                    CopyFolder(PatchPathCommon + "MODEL", GDI1Path + "MODEL", true);
                    CopyFolder(PatchPathCommon + "SPRITE", GDI1Path + "SPRITE", true);

                    //Generar DUMMY
                    FileStream Dummy = new FileStream(GDI1Path + "DUMMY.DAT", FileMode.Create, FileAccess.Write);
                    BinaryWriter bw = new BinaryWriter(Dummy);
                    for (int n = 0; n < (55 * 262144); n++) bw.Write((int)0); //55MB
                    bw.Close();
                    Dummy.Close();
                }

                //Disco 2
                if (GDI[1] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Reemplazando archivos del disco nº2...");

                    CopyFolder(PatchPath2 + "SCENE" + DirSep + "02" + DirSep + "D000", GDI2Path + "SCENE" + DirSep + "02" + DirSep + "D000", true);
                    CopyFolder(PatchPath2 + "SCENE" + DirSep + "02" + DirSep + "DBYO", GDI2Path + "SCENE" + DirSep + "02" + DirSep + "DBYO", true);
                    CopyFolder(PatchPath2 + "SCENE" + DirSep + "02" + DirSep + "JD00", GDI2Path + "SCENE" + DirSep + "02" + DirSep + "JD00", true);
                    CopyFolder(PatchPath2 + "SCENE" + DirSep + "02" + DirSep + "JOMO", GDI2Path + "SCENE" + DirSep + "02" + DirSep + "JOMO", true);
                    CopyFolder(PatchPath2 + "SCENE" + DirSep + "02" + DirSep + "MFSY", GDI2Path + "SCENE" + DirSep + "02" + DirSep + "MFSY", true);
                    CopyFolder(PatchPath2 + "SCENE" + DirSep + "02" + DirSep + "MKSG", GDI2Path + "SCENE" + DirSep + "02" + DirSep + "MKSG", true);
                    CopyFolder(PatchPath2 + "SCENE" + DirSep + "02" + DirSep + "MKYU", GDI2Path + "SCENE" + DirSep + "02" + DirSep + "MKYU", true);

                    //Archivos comunes a los 3 primeros CDs
                    CopyFolder(PatchPathCommon + "MISC", GDI2Path + "MISC", true);
                    CopyFolder(PatchPathCommon + "MODEL", GDI2Path + "MODEL", true);
                    CopyFolder(PatchPathCommon + "SPRITE", GDI2Path + "SPRITE", true);

                    //Generar DUMMY
                    FileStream Dummy = new FileStream(GDI2Path + "DUMMY.DAT", FileMode.Create, FileAccess.Write);
                    BinaryWriter bw = new BinaryWriter(Dummy);
                    for (int n = 0; n < (123 * 262144); n++) bw.Write((int)0); //123MB
                    bw.Close();
                    Dummy.Close();
                }

                //Disco 3
                if (GDI[2] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Reemplazando archivos del disco nº3...");

                    CopyFolder(PatchPath3 + "SCENE" + DirSep + "03" + DirSep + "D000", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "D000", true);
                    CopyFolder(PatchPath3 + "SCENE" + DirSep + "03" + DirSep + "DBYO", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "DBYO", true);
                    CopyFolder(PatchPath3 + "SCENE" + DirSep + "03" + DirSep + "JD00", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "JD00", true);
                    CopyFolder(PatchPath3 + "SCENE" + DirSep + "03" + DirSep + "JOMO", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "JOMO", true);
                    CopyFolder(PatchPath3 + "SCENE" + DirSep + "03" + DirSep + "MA00", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "MA00", true);
                    CopyFolder(PatchPath3 + "SCENE" + DirSep + "03" + DirSep + "MBQC", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "MBQC", true);
                    CopyFolder(PatchPath3 + "SCENE" + DirSep + "03" + DirSep + "MC5Q", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "MC5Q", true);
                    CopyFolder(PatchPath3 + "SCENE" + DirSep + "03" + DirSep + "MEND", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "MEND", true);
                    CopyFolder(PatchPath3 + "SCENE" + DirSep + "03" + DirSep + "MFSY", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "MFSY", true);
                    CopyFolder(PatchPath3 + "SCENE" + DirSep + "03" + DirSep + "MKSG", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "MKSG", true);
                    CopyFolder(PatchPath3 + "SCENE" + DirSep + "03" + DirSep + "MKYU", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "MKYU", true);
                    //CopyFolder(PatchPath3 + "SCENE"+ DirSep+"03"+ DirSep+"NBIK", GDI3Path + "SCENE"+ DirSep+"03"+ DirSep+"NBIK", true);

                    //Archivos comunes a los 3 primeros CDs
                    CopyFolder(PatchPathCommon + "MISC", GDI3Path + "MISC", true);
                    CopyFolder(PatchPathCommon + "MODEL", GDI3Path + "MODEL", true);
                    CopyFolder(PatchPathCommon + "SPRITE", GDI3Path + "SPRITE", true);

                    //Generar DUMMY
                    FileStream Dummy = new FileStream(GDI3Path + "DUMMY.DAT", FileMode.Create, FileAccess.Write);
                    BinaryWriter bw = new BinaryWriter(Dummy);
                    for (int n = 0; n < (45 * 262144); n++) bw.Write((int)0); //45MB
                    bw.Close();
                    Dummy.Close();
                }

                //Disco 4
                if (GDI[3] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Reemplazando archivos del disco nº4...");

                    CopyFolder(PatchPath4 + "SCENE" + DirSep + "99" + DirSep + "NBIK", GDI4Path + "SCENE" + DirSep + "99" + DirSep + "NBIK", true);

                    CopyFolder(PatchPath4 + "MISC", GDI4Path + "MISC", true);
                    CopyFolder(PatchPath4 + "MODEL", GDI4Path + "MODEL", true);
                    CopyFolder(PatchPath4 + "PASSPORT", GDI4Path + "PASSPORT", true);
                    CopyFolder(PatchPath4 + "SPRITE", GDI4Path + "SPRITE", true);
                }

                #endregion

                #region AFS

                AFS Afs = new AFS();

                //Disco 1
                if (GDI[0] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Exportando archivos AFS del disco nº1...");

                    string[] AFSFiles = Directory.GetFiles(GDI1Path + "SCENE" + DirSep + "01" + DirSep + "STREAM", "*.afs");

                    for (int n = 0; n < AFSFiles.Length; n++)
                    {
                        Afs.ExtractAFS(AFSFiles[n], Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]), Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".list");
                    }

                    //Reemplazar los SRF extraidos por los del parche
                    Parcheo.ReportProgress(Progress++, "Reemplazando archivos SRF del disco nº1...");
                    CopyFolder(PatchPath1 + "SCENE" + DirSep + "01" + DirSep + "STREAM", GDI1Path + "SCENE" + DirSep + "01" + DirSep + "STREAM", true);

                    //Recrear los AFS
                    Parcheo.ReportProgress(Progress++, "Regenerando archivos AFS del disco nº1...");

                    for (int n = 0; n < AFSFiles.Length; n++)
                    {
                        Afs.CreateAFS(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]), AFSFiles[n] + "2", Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".list");
                        File.Delete(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".list");
                        Directory.Delete(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]), true);

                        if (Path.GetFileNameWithoutExtension(AFSFiles[n]) != "HUMANS")
                        {
                            if (StartProcess(UtilsPath + "idxmaker.exe", "-1 \"" + AFSFiles[n] + "2\" \"" + Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX2\" \"" + AFSFiles[n] + "\" \"" + Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX\"", "", true) != 0) return;
                            File.Delete(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX");
                            File.Move(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX2", Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX");
                        }

                        File.Delete(AFSFiles[n]);
                        File.Move(AFSFiles[n] + "2", AFSFiles[n]);
                    }

                    //Reemplazo de voces (exclusivo del CD1 y 4)
                    if (IdiomaSeleccionado == 0)
                    {
                        File.Copy(PatchPathCommon + "voces" + DirSep + "A0100.AFS-ES", GDI1Path + "SCENE" + DirSep + "01" + DirSep + "STREAM" + DirSep + "A0100.AFS", true);
                        File.Copy(PatchPathCommon + "voces" + DirSep + "A0100.IDX-ES", GDI1Path + "SCENE" + DirSep + "01" + DirSep + "STREAM" + DirSep + "A0100.IDX", true);
                    }
                    else if (IdiomaSeleccionado == 1)
                    {
                        File.Copy(PatchPathCommon + "voces" + DirSep + "A0100.AFS-MX", GDI1Path + "SCENE" + DirSep + "01" + DirSep + "STREAM" + DirSep + "A0100.AFS", true);
                        File.Copy(PatchPathCommon + "voces" + DirSep + "A0100.IDX-MX", GDI1Path + "SCENE" + DirSep + "01" + DirSep + "STREAM" + DirSep + "A0100.IDX", true);
                    }
                }

                //Disco 2
                if (GDI[1] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Exportando archivos AFS del disco nº2...");

                    string[] AFSFiles = Directory.GetFiles(GDI2Path + "SCENE" + DirSep + "02" + DirSep + "STREAM", "*.afs");

                    for (int n = 0; n < AFSFiles.Length; n++)
                    {
                        Afs.ExtractAFS(AFSFiles[n], Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]), Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".list");
                    }

                    //Reemplazar los SRF extraidos por los del parche
                    Parcheo.ReportProgress(Progress++, "Reemplazando archivos SRF del disco nº2...");
                    CopyFolder(PatchPath2 + "SCENE" + DirSep + "02" + DirSep + "STREAM", GDI2Path + "SCENE" + DirSep + "02" + DirSep + "STREAM", true);

                    //Recrear los AFS
                    Parcheo.ReportProgress(Progress++, "Regenerando archivos AFS del disco nº2...");

                    for (int n = 0; n < AFSFiles.Length; n++)
                    {
                        Afs.CreateAFS(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]), AFSFiles[n] + "2", Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".list");
                        File.Delete(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".list");
                        Directory.Delete(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]), true);

                        if (Path.GetFileNameWithoutExtension(AFSFiles[n]) != "HUMANS")
                        {
                            if (StartProcess(UtilsPath + "idxmaker.exe", "-1 \"" + AFSFiles[n] + "2\" \"" + Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX2\" \"" + AFSFiles[n] + "\" \"" + Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX\"", "", true) != 0) return;
                            File.Delete(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX");
                            File.Move(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX2", Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX");
                        }

                        File.Delete(AFSFiles[n]);
                        File.Move(AFSFiles[n] + "2", AFSFiles[n]);
                    }
                }

                //Disco 3
                if (GDI[2] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Exportando archivos AFS del disco nº3...");

                    string[] AFSFiles = Directory.GetFiles(GDI3Path + "SCENE" + DirSep + "03" + DirSep + "STREAM", "*.afs");

                    for (int n = 0; n < AFSFiles.Length; n++)
                    {
                        Afs.ExtractAFS(AFSFiles[n], Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]), Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".list");
                    }

                    //Reemplazar los SRF extraidos por los del parche
                    Parcheo.ReportProgress(Progress++, "Reemplazando archivos SRF del disco nº3...");
                    CopyFolder(PatchPath3 + "SCENE" + DirSep + "03" + DirSep + "STREAM", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "STREAM", true);

                    //Reemplazo de un archivo de voz exclusivo de los CDs 3 y 4
                    if (IdiomaSeleccionado == 0)
                    {
                        File.Copy(PatchPathCommon + "voces" + DirSep + "end.str-ES", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "STREAM" + DirSep + "BGM03" + DirSep + "end.str", true);
                    }
                    else if (IdiomaSeleccionado == 1)
                    {
                        File.Copy(PatchPathCommon + "voces" + DirSep + "end.str-MX", GDI3Path + "SCENE" + DirSep + "03" + DirSep + "STREAM" + DirSep + "BGM03" + DirSep + "end.str", true);
                    }

                    //Recrear los AFS
                    Parcheo.ReportProgress(Progress++, "Regenerando archivos AFS del disco nº3...");

                    for (int n = 0; n < AFSFiles.Length; n++)
                    {
                        Afs.CreateAFS(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]), AFSFiles[n] + "2", Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".list");
                        File.Delete(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".list");
                        Directory.Delete(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]), true);

                        if (Path.GetFileNameWithoutExtension(AFSFiles[n]) != "HUMANS")
                        {
                            if (StartProcess(UtilsPath + "idxmaker.exe", "-1 \"" + AFSFiles[n] + "2\" \"" + Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX2\" \"" + AFSFiles[n] + "\" \"" + Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX\"", "", true) != 0) return;
                            File.Delete(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX");
                            File.Move(Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX2", Path.GetDirectoryName(AFSFiles[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles[n]) + ".IDX");
                        }

                        File.Delete(AFSFiles[n]);
                        File.Move(AFSFiles[n] + "2", AFSFiles[n]);
                    }

                    //MODIFICAR NO SÉ QUE VIDEO -----------------------------------------------------------------------------------------------
                }

                //Disco 4
                if (GDI[3] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Exportando archivos AFS del disco nº4...");

                    string[] AFSFiles01 = Directory.GetFiles(GDI4Path + "SCENE" + DirSep + "01" + DirSep + "STREAM", "*.afs");
                    string[] AFSFiles80 = Directory.GetFiles(GDI4Path + "SCENE" + DirSep + "80" + DirSep + "STREAM", "*.afs");
                    string[] AFSFiles99 = Directory.GetFiles(GDI4Path + "SCENE" + DirSep + "99" + DirSep + "STREAM", "*.afs");

                    for (int n = 0; n < AFSFiles01.Length; n++)
                    {
                        Afs.ExtractAFS(AFSFiles01[n], Path.GetDirectoryName(AFSFiles01[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles01[n]), Path.GetDirectoryName(AFSFiles01[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles01[n]) + ".list");
                    }

                    for (int n = 0; n < AFSFiles80.Length; n++)
                    {
                        Afs.ExtractAFS(AFSFiles80[n], Path.GetDirectoryName(AFSFiles80[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles80[n]), Path.GetDirectoryName(AFSFiles80[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles80[n]) + ".list");
                    }

                    for (int n = 0; n < AFSFiles99.Length; n++)
                    {
                        Afs.ExtractAFS(AFSFiles99[n], Path.GetDirectoryName(AFSFiles99[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles99[n]), Path.GetDirectoryName(AFSFiles99[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles99[n]) + ".list");
                    }

                    //Reemplazar los SRF extraidos por los del parche
                    Parcheo.ReportProgress(Progress++, "Reemplazando archivos SRF del disco nº4...");
                    CopyFolder(PatchPath4 + "SCENE", GDI4Path + "SCENE", true);

                    //Reemplazo de un archivo de voz exclusivo de los CDs 3 y 4
                    if (IdiomaSeleccionado == 0)
                    {
                        File.Copy(PatchPathCommon + "voces" + DirSep + "end.str-ES", GDI4Path + "SCENE" + DirSep + "99" + DirSep + "STREAM" + DirSep + "BGM03" + DirSep + "end.str", true);
                    }
                    else if (IdiomaSeleccionado == 1)
                    {
                        File.Copy(PatchPathCommon + "voces" + DirSep + "end.str-MX", GDI4Path + "SCENE" + DirSep + "99" + DirSep + "STREAM" + DirSep + "BGM03" + DirSep + "end.str", true);
                    }

                    //Recrear los AFS
                    Parcheo.ReportProgress(Progress++, "Regenerando archivos AFS del disco nº4...");

                    for (int n = 0; n < AFSFiles01.Length; n++)
                    {
                        Afs.CreateAFS(Path.GetDirectoryName(AFSFiles01[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles01[n]), AFSFiles01[n] + "2", Path.GetDirectoryName(AFSFiles01[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles01[n]) + ".list");
                        File.Delete(Path.GetDirectoryName(AFSFiles01[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles01[n]) + ".list");
                        Directory.Delete(Path.GetDirectoryName(AFSFiles01[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles01[n]), true);

                        if (Path.GetFileNameWithoutExtension(AFSFiles01[n]) != "HUMANS")
                        {
                            if (StartProcess(UtilsPath + "idxmaker.exe", "-1 \"" + AFSFiles01[n] + "2\" \"" + Path.GetDirectoryName(AFSFiles01[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles01[n]) + ".IDX2\" \"" + AFSFiles01[n] + "\" \"" + Path.GetDirectoryName(AFSFiles01[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles01[n]) + ".IDX\"", "", true) != 0) return;
                            File.Delete(Path.GetDirectoryName(AFSFiles01[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles01[n]) + ".IDX");
                            File.Move(Path.GetDirectoryName(AFSFiles01[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles01[n]) + ".IDX2", Path.GetDirectoryName(AFSFiles01[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles01[n]) + ".IDX");
                        }

                        File.Delete(AFSFiles01[n]);
                        File.Move(AFSFiles01[n] + "2", AFSFiles01[n]);
                    }

                    for (int n = 0; n < AFSFiles80.Length; n++)
                    {
                        Afs.CreateAFS(Path.GetDirectoryName(AFSFiles80[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles80[n]), AFSFiles80[n] + "2", Path.GetDirectoryName(AFSFiles80[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles80[n]) + ".list");
                        File.Delete(Path.GetDirectoryName(AFSFiles80[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles80[n]) + ".list");
                        Directory.Delete(Path.GetDirectoryName(AFSFiles80[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles80[n]), true);

                        if (Path.GetFileNameWithoutExtension(AFSFiles80[n]) != "HUMANS")
                        {
                            if (StartProcess(UtilsPath + "idxmaker.exe", "-1 \"" + AFSFiles80[n] + "2\" \"" + Path.GetDirectoryName(AFSFiles80[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles80[n]) + ".IDX2\" \"" + AFSFiles80[n] + "\" \"" + Path.GetDirectoryName(AFSFiles80[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles80[n]) + ".IDX\"", "", true) != 0) return;
                            File.Delete(Path.GetDirectoryName(AFSFiles80[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles80[n]) + ".IDX");
                            File.Move(Path.GetDirectoryName(AFSFiles80[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles80[n]) + ".IDX2", Path.GetDirectoryName(AFSFiles80[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles80[n]) + ".IDX");
                        }

                        File.Delete(AFSFiles80[n]);
                        File.Move(AFSFiles80[n] + "2", AFSFiles80[n]);
                    }

                    for (int n = 0; n < AFSFiles99.Length; n++)
                    {
                        Afs.CreateAFS(Path.GetDirectoryName(AFSFiles99[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles99[n]), AFSFiles99[n] + "2", Path.GetDirectoryName(AFSFiles99[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles99[n]) + ".list");
                        File.Delete(Path.GetDirectoryName(AFSFiles99[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles99[n]) + ".list");
                        Directory.Delete(Path.GetDirectoryName(AFSFiles99[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles99[n]), true);

                        if (Path.GetFileNameWithoutExtension(AFSFiles99[n]) != "HUMANS")
                        {
                            if (StartProcess(UtilsPath + "idxmaker.exe", "-1 \"" + AFSFiles99[n] + "2\" \"" + Path.GetDirectoryName(AFSFiles99[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles99[n]) + ".IDX2\" \"" + AFSFiles99[n] + "\" \"" + Path.GetDirectoryName(AFSFiles99[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles99[n]) + ".IDX\"", "", true) != 0) return;
                            File.Delete(Path.GetDirectoryName(AFSFiles99[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles99[n]) + ".IDX");
                            File.Move(Path.GetDirectoryName(AFSFiles99[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles99[n]) + ".IDX2", Path.GetDirectoryName(AFSFiles99[n]) + DirSep + Path.GetFileNameWithoutExtension(AFSFiles99[n]) + ".IDX");
                        }

                        File.Delete(AFSFiles99[n]);
                        File.Move(AFSFiles99[n] + "2", AFSFiles99[n]);
                    }

                    //Reemplazo de voces (exclusivo del CD1 y 4)
                    if (IdiomaSeleccionado == 0)
                    {
                        File.Copy(PatchPathCommon + "voces" + DirSep + "A0100.AFS-ES", GDI4Path + "SCENE" + DirSep + "99" + DirSep + "STREAM" + DirSep + "A0100.AFS", true);
                        File.Copy(PatchPathCommon + "voces" + DirSep + "A0100.IDX-ES", GDI4Path + "SCENE" + DirSep + "99" + DirSep + "STREAM" + DirSep + "A0100.IDX", true);
                    }
                    else if (IdiomaSeleccionado == 1)
                    {
                        File.Copy(PatchPathCommon + "voces" + DirSep + "A0100.AFS-MX", GDI4Path + "SCENE" + DirSep + "99" + DirSep + "STREAM" + DirSep + "A0100.AFS", true);
                        File.Copy(PatchPathCommon + "voces" + DirSep + "A0100.IDX-MX", GDI4Path + "SCENE" + DirSep + "99" + DirSep + "STREAM" + DirSep + "A0100.IDX", true);
                    }
                }

                #endregion

                #region Vídeos del CD4

                //Disco 4
                if (GDI[3] != String.Empty)
                {
                    string[] video = new string[5];
                    video[0] = GDI4Path + "SP_01";
                    video[1] = GDI4Path + "SP_11";
                    video[2] = GDI4Path + "SP_17";
                    video[3] = GDI4Path + "SP_18";
                    video[4] = GDI4Path + "SP_19";

                    string[] subs = new string[] { PatchPath4 + "subs" + DirSep + "SP_01.srt", PatchPath4 + "subs" + DirSep + "SP_11.srt", PatchPath4 + "subs" + DirSep + "SP_17.srt", PatchPath4 + "subs" + DirSep + "SP_18.srt", PatchPath4 + "subs" + DirSep + "SP_19.srt" };

                    for (int n = 0; n < video.Length; n++)
                    {
                        Parcheo.ReportProgress(Progress++, "Recodificando vídeo " + (n + 1).ToString() + "/" + video.Length + " del disco nº4...");

                        if (StartProcess(UtilsPath + "mpgtx.exe", "-f -b \"" + video[n] + "\" -d \"" + video[n] + ".SFD\"") != 0) return;
                        //if(StartProcess(UtilsPath + "ffmpeg.exe", "-y -i \"" + video[n] + "-0.m1v\" -vcodec mpeg1video -b:v 450k -mbd rd -trellis 2 -cmp 2 -subcmp 2 -bf 2 -pass 1 -an -passlogfile \"" + video[n] + "\" \"" + video[n] + ".mpg\"");
                        //if(StartProcess(UtilsPath + "ffmpeg.exe", "-y -i \"" + video[n] + "-0.m1v\" -vcodec mpeg1video -b:v 450k -mbd rd -trellis 2 -cmp 2 -subcmp 2 -bf 2 -pass 2 -an -passlogfile \"" + video[n] + "\" \"" + video[n] + ".mpg\"");

                        if (StartProcess(UtilsPath + "mencoder.exe", "\"" + video[n] + "-0.m1v\" -sub \"" + subs[n] + "\" -font \"" + PatchPath4 + "subs" + DirSep + "font.ttf\" -subcp latin1 -subfont-text-scale 3 -subpos 90 -of rawvideo -mpegopts format=mpeg1:tsaf:muxrate=2000 -o \"" + video[n] + ".mpg\" -ovc lavc -lavcopts vcodec=mpeg1video:vbitrate=2000:vpass=1:keyint=15:vmax_b_frames=2:mbd=2:aspect=4/3", UtilsPath, true) != 0) return;
                        if (StartProcess(UtilsPath + "mencoder.exe", "\"" + video[n] + "-0.m1v\" -sub \"" + subs[n] + "\" -font \"" + PatchPath4 + "subs" + DirSep + "font.ttf\" -subcp latin1 -subfont-text-scale 3 -subpos 90 -of rawvideo -mpegopts format=mpeg1:tsaf:muxrate=2000 -o \"" + video[n] + ".mpg\" -ovc lavc -lavcopts vcodec=mpeg1video:vbitrate=2000:vpass=2:keyint=15:vmax_b_frames=2:mbd=2:aspect=4/3", UtilsPath, true) != 0) return;

                        StartProcess(UtilsPath + "sfdmux.exe", "-V=\"" + video[n] + ".mpg\" -A=\"" + video[n] + "-0.mp1\" -S=\"" + video[n] + "_2.SFD\"", "", true);

                        if (File.Exists(video[n] + "_2.SFD") == false)
                        {
                            MessageBox.Show("Ha habido un problema al convertir de .mpg a .sfd el vídeo " + Path.GetFileName(video[n]) + ".\n\nEl parcheador no puede continuar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Parcheo.ReportProgress(0, "En espera...");
                            return;
                        }

                        //mencoder SP_01-0.m1v -sub lol2.srt -font calibri.ttf -subcp latin1 -of rawvideo -mpegopts format=mpeg1:tsaf:muxrate=2000 -o output.mpg -ovc lavc -lavcopts vcodec=mpeg1video:vbitrate=600:keyint=15:mbd=2:aspect=4/3

                        File.Delete(video[n] + ".SFD");
                        File.Move(video[n] + "_2.SFD", video[n] + ".SFD");

                        //File.Delete(video[n] + "-0.log");
                        File.Delete(video[n] + "-0.mp1");
                        File.Delete(video[n] + "-0.m1v");
                        File.Delete(video[n] + ".mpg");
                    }
                }

                #endregion

                #region Generando ISOs finales

                if (Directory.Exists(FinalISOPath) == false) Directory.CreateDirectory(FinalISOPath);

                //Disco 1
                if (GDI[0] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Generando ISO final del disco nº1...");

                    //mkisofs -C 0,12845 -V SHENMUE_DISC1 -G IP.01.BIN -sort sorttxt1.txt -duplicates-once -joliet -rock -l -o test01.ISO SHENMUE_DISC1
                    if (StartProcess(UtilsPath + "mkisofs.exe", "-C 0,12845 -V SHENMUE_DISC1 -G \"" + IPPath + "IP1.BIN\" -sort \"" + PatchPath + "sorttxt1.txt\" -duplicates-once -joliet -rock -l -o \"" + FinalISO1 + ".iso\" \"" + GDI1Path + "\"") != 0) return;
                    //mds4dc -c disco1CDDA.MDS test01.ISO track04.01.raw track05.01.raw
                    if (StartProcess(UtilsPath + "mds4dc.exe", "-c \"" + FinalISO1 + ".mds\" \"" + FinalISO1 + ".iso\" \"" + TracksGDI1[3] + "\" \"" + TracksGDI1[4] + "\"") != 0) return;

                    File.Delete(FinalISO1 + ".iso");
                }

                //Disco 2
                if (GDI[1] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Generando ISO final del disco nº2...");

                    //mkisofs -C 0,11702 -V SHENMUE_DISC2 -G IP.02.BIN -sort sorttxt2.txt -duplicates-once -joliet -rock -l -o test02.ISO SHENMUE_DISC2
                    //mds4dc -a disco2CDDA.MDS test02.ISO
                    if (StartProcess(UtilsPath + "mkisofs.exe", "-C 0,12845 -V SHENMUE_DISC2 -G \"" + IPPath + "IP2.BIN\" -sort \"" + PatchPath + "sorttxt2.txt\" -duplicates-once -joliet -rock -l -o \"" + FinalISO2 + ".iso\" \"" + GDI2Path + "\"") != 0) return;
                    if (StartProcess(UtilsPath + "mds4dc.exe", "-c \"" + FinalISO2 + ".mds\" \"" + FinalISO2 + ".iso\" \"" + TracksGDI2[3] + "\" \"" + TracksGDI2[4] + "\"") != 0) return;

                    File.Delete(FinalISO2 + ".iso");
                }

                //Disco 3
                if (GDI[2] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Generando ISO final del disco nº3...");

                    //mkisofs -C 0,21588 -V SHENMUE_DISC3 -G IP.03.BIN -sort sorttxt3.txt -duplicates-once -joliet -rock -l -o test03.ISO SHENMUE_DISC3
                    //mds4dc -c disco3CDDA.MDS test03.ISO track04.03.raw track05.03.raw
                    if (StartProcess(UtilsPath + "mkisofs.exe", "-C 0,21588 -V SHENMUE_DISC3 -G \"" + IPPath + "IP3.BIN\" -sort \"" + PatchPath + "sorttxt3.txt\" -duplicates-once -joliet -rock -l -o \"" + FinalISO3 + ".iso\" \"" + GDI3Path + "\"") != 0) return;
                    if (StartProcess(UtilsPath + "mds4dc.exe", "-c \"" + FinalISO3 + ".mds\" \"" + FinalISO3 + ".iso\" \"" + TracksGDI3[3] + "\" \"" + TracksGDI3[4] + "\"") != 0) return;

                    File.Delete(FinalISO3 + ".iso");
                }

                //Disco 4
                if (GDI[3] != String.Empty)
                {
                    Parcheo.ReportProgress(Progress++, "Generando ISO final del disco nº4...");

                    //mkisofs -C 0,22506 -V SHENMUE_DISC4 -G IP.04.BIN -sort sorttxt4.txt -duplicates-once -joliet -rock -l -o test04.ISO SHENMUE_DISC4
                    //mds4dc -c disco4CDDA.MDS test04.ISO track04.04.raw track05.04.raw track06.04.raw
                    if (StartProcess(UtilsPath + "mkisofs.exe", "-C 0,22506 -V SHENMUE_DISC4 -G \"" + IPPath + "IP4.BIN\" -sort \"" + PatchPath + "sorttxt4.txt\" -duplicates-once -joliet -rock -l -o \"" + FinalISO4 + ".iso\" \"" + GDI4Path + "\"") != 0) return;
                    if (StartProcess(UtilsPath + "mds4dc.exe", "-c \"" + FinalISO4 + ".mds\" \"" + FinalISO4 + ".iso\" \"" + TracksGDI4[3] + "\" \"" + TracksGDI4[4] + "\" \"" + TracksGDI4[5] + "\"") != 0) return;

                    File.Delete(FinalISO4 + ".iso");
                }

                #endregion

                Parcheo.ReportProgress(ProgressMax, "Proceso finalizado con éxito.");
#if !DEBUG
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
                Parcheo.ReportProgress(ProgressMax, "El proceso no se ha podido completar.");
            }
#endif
        }

        private void Parcheo_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (Directory.Exists(TempPath)) Directory.Delete(TempPath, true);
            SystemSounds.Beep.Play();
            EnableControls(true);
            Parcheando = false;
            LogStream.Close();
        }

        private void Parcheo_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            Progress.Value = e.ProgressPercentage;
            Status.Text = e.UserState.ToString();
        }

        /*int StartProcess2(string pathToProgram, string args = "", string WorkingDir = "")
        {
            string outputString = string.Empty;
            string errorString = string.Empty;

            using (Process process = new Process())
            {
                ProcessStartInfo processStartInfo = new ProcessStartInfo();

                processStartInfo.FileName = pathToProgram;
                processStartInfo.Arguments = args;
                processStartInfo.CreateNoWindow = true;
                processStartInfo.UseShellExecute = false;

                if (WorkingDir == "") processStartInfo.WorkingDirectory = AppPath;
                else processStartInfo.WorkingDirectory = WorkingDir;

                processStartInfo.RedirectStandardOutput = true;
                process.OutputDataReceived += (sender, e) => outputString += e.Data;

                processStartInfo.RedirectStandardError = true;
                process.ErrorDataReceived += (sender, e) => errorString += e.Data;

                process.StartInfo = processStartInfo;

                process.Start();

                process.BeginOutputReadLine();
                process.BeginErrorReadLine();

                process.WaitForExit(30000);

                //if (!process.HasExited) process.Kill();

                logText += pathToProgram + "\n";
                logText += "############## OUTPUT ################\n" + outputString + "\n\n";
                logText += "############## ERROR ################\n" + errorString + "\n\n";

                if (process.ExitCode != 0)
                {
                    string comando = Path.GetFileName(pathToProgram) + " " + args;
                    MessageBox.Show("Código " + process.ExitCode.ToString() + " al ejecutar:\n\n" + comando + "\n\nPulsa Ctrl+C para copiar este mensaje al portapapeles.");
                }

                return process.ExitCode;
            }
        }*/

        int StartProcess(string exe, string arguments = "", string WorkingDir = "", bool log = false)
        {
            Process process = new Process();

            if (Environment.OSVersion.Platform == PlatformID.Unix)
            {
                if (Path.GetFileName(exe) == "mkisofs.exe")
                {
                    process.StartInfo.FileName = "mkisofs";
                    process.StartInfo.Arguments = arguments;
                }
                else
                {
                    process.StartInfo.FileName = "wine";
                    process.StartInfo.Arguments = exe + " " + arguments;
                }
            }
            else
            {
                process.StartInfo.FileName = exe;
                process.StartInfo.Arguments = arguments;
            }

            if (log == false)
            {
                process.StartInfo.RedirectStandardOutput = false;
                process.StartInfo.RedirectStandardInput = false;
                process.StartInfo.RedirectStandardError = false;
            }
            else
            {
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardInput = true;
                process.StartInfo.RedirectStandardError = true;
            }

            if (WorkingDir == "") process.StartInfo.WorkingDirectory = AppPath;
            else process.StartInfo.WorkingDirectory = WorkingDir;

            process.StartInfo.UseShellExecute = false;
            process.StartInfo.CreateNoWindow = true;
            process.Start();

            LogStream.Write(process.StartInfo.FileName + " " + process.StartInfo.Arguments + "\n");
            
            if (log == true)
            {
                LogStream.Write("################# OUTPUT STREAM #################\n" + process.StandardOutput.ReadToEnd() + "\n\n");
                LogStream.Write("################# ERROR  STREAM #################\n" + process.StandardError.ReadToEnd() + "\n\n");
            }

            process.WaitForExit();

            if (process.ExitCode != 0)
            {
                string comando = process.StartInfo.FileName + " " + process.StartInfo.Arguments;
                MessageBox.Show("Código " + process.ExitCode.ToString() + " al ejecutar:\n\n" + comando + "\n\nPulsa Ctrl+C para copiar este mensaje al portapapeles.");
            }

            int ExitCode = process.ExitCode;

            process.Dispose();

            return ExitCode;
        }

        void CopyFolder(string sourceFolder, string destFolder, bool overwrite)
        {
            if (!Directory.Exists(destFolder)) Directory.CreateDirectory(destFolder);
            string[] files = Directory.GetFiles(sourceFolder);

            foreach (string file in files)
            {
                string name = Path.GetFileName(file);
                string dest = Path.Combine(destFolder, name);
                File.Copy(file, dest, overwrite);
            }

            string[] folders = Directory.GetDirectories(sourceFolder);

            foreach (string folder in folders)
            {
                string name = Path.GetFileName(folder);
                string dest = Path.Combine(destFolder, name);
                CopyFolder(folder, dest, overwrite);
            }
        }

        int ReadLBA(string file)
        {
            string[] lines = File.ReadAllLines(file);
            char[] delimiterChars = { ' ' };

            int NumeroLineas = Convert.ToInt32(lines[0]);

            string[] words = lines[NumeroLineas].Split(delimiterChars);

            return Convert.ToInt32(words[1]) + 150;
        }

        string[] ReadTracksNames(string file)
        {
            string[] lines = File.ReadAllLines(file);
            char[] delimiterChars = { ' ' };

            int NumeroLineas = Convert.ToInt32(lines[0]);
            string[] Pistas = new string[NumeroLineas];

            for (int n = 0; n < NumeroLineas; n++)
            {
                string[] words = lines[n + 1].Split(delimiterChars);
                Pistas[n] = Path.GetDirectoryName(file) + DirSep + words[4];
            }

            return Pistas;
        }

        void Descomprimir(Stream stream, string OutputDirectory)
        {
            if (OutputDirectory.EndsWith(DirSep) == false) OutputDirectory += DirSep;

            using (ZipInputStream s = new ZipInputStream(stream))
            {
                ZipEntry theEntry;

                while ((theEntry = s.GetNextEntry()) != null)
                {
                    string directoryName = Path.GetDirectoryName(theEntry.Name);
                    string fileName = Path.GetFileName(theEntry.Name);

                    // create directory
                    if (directoryName.Length > 0)
                    {
                        Directory.CreateDirectory(OutputDirectory + directoryName);
                    }

                    if (fileName != String.Empty)
                    {
                        using (FileStream streamWriter = File.Create(OutputDirectory + theEntry.Name))
                        {
                            int size = 2048;
                            byte[] data = new byte[2048];
                            while (true)
                            {
                                size = s.Read(data, 0, data.Length);
                                if (size > 0)
                                {
                                    streamWriter.Write(data, 0, size);
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        public static void DecompressFileLZMA(string inResource, string outFile)
        {
            using (Stream input = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(inResource))
            {
                using (FileStream output = new FileStream(outFile, FileMode.Create))
                {
                    SevenZip.Compression.LZMA.Decoder decoder = new SevenZip.Compression.LZMA.Decoder();

                    byte[] properties = new byte[5];
                    if (input.Read(properties, 0, 5) != 5)
                        throw (new Exception("input .lzma is too short"));
                    decoder.SetDecoderProperties(properties);

                    long outSize = 0;
                    for (int i = 0; i < 8; i++)
                    {
                        int v = input.ReadByte();
                        if (v < 0)
                            throw (new Exception("Can't Read 1"));
                        outSize |= ((long)(byte)v) << (8 * i);
                    }
                    long compressedSize = input.Length - input.Position;

                    decoder.Code(input, output, compressedSize, outSize, null);
                }
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Parcheando == true)
            {
                MessageBox.Show("El parcheador está ocupado. Tendrás que esperar a que termine.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Cancel = true;
                return;
            }

            if (Directory.Exists(TempPath)) Directory.Delete(TempPath, true);
        }

        /*private void button6_Click(object sender, EventArgs e)
        {
            string[] video = new string[5];
            video[0] = GDI4Path + "SP_01";
            video[1] = GDI4Path + "SP_11";
            video[2] = GDI4Path + "SP_17";
            video[3] = GDI4Path + "SP_18";
            video[4] = GDI4Path + "SP_19";

            string[] subs = new string[] { PatchPath4 + "subs" + DirSep + "SP_01.srt", PatchPath4 + "subs" + DirSep + "SP_11.srt", PatchPath4 + "subs" + DirSep + "SP_17.srt", PatchPath4 + "subs" + DirSep + "SP_18.srt", PatchPath4 + "subs" + DirSep + "SP_19.srt" };

            for (int n = 0; n < 5; n++)
            {
                if (StartProcess(UtilsPath + "mpgtx.exe", "-f -b \"" + video[n] + "\" -d \"" + video[n] + ".SFD\"") != 0) return;
                //if(StartProcess(UtilsPath + "ffmpeg.exe", "-y -i \"" + video[n] + "-0.m1v\" -vcodec mpeg1video -b:v 450k -mbd rd -trellis 2 -cmp 2 -subcmp 2 -bf 2 -pass 1 -an -passlogfile \"" + video[n] + "\" \"" + video[n] + ".mpg\"");
                //if(StartProcess(UtilsPath + "ffmpeg.exe", "-y -i \"" + video[n] + "-0.m1v\" -vcodec mpeg1video -b:v 450k -mbd rd -trellis 2 -cmp 2 -subcmp 2 -bf 2 -pass 2 -an -passlogfile \"" + video[n] + "\" \"" + video[n] + ".mpg\"");

                if (StartProcess(UtilsPath + "mencoder.exe", "\"" + video[n] + "-0.m61v\" -sub \"" + subs[n] + "\" -font \"" + PatchPath4 + "subs" + DirSep + "font.ttf\" -subcp latin1 -subfont-text-scale 3 -subpos 90 -of rawvideo -mpegopts format=mpeg1:tsaf:muxrate=2000 -o \"" + video[n] + ".mpg\" -ovc lavc -lavcopts vcodec=mpeg1video:vbitrate=450:keyint=15:vmax_b_frames=2:mbd=2:aspect=4/3", UtilsPath) != 0) return;
                //if(StartProcess(UtilsPath + "mencoder.exe", "\"" + video[n] + "-0.m1v\" -sub \"" + subs[n] + "\" -font \"" + PatchPath4 + "subs" + DirSep + "font.ttf\" -subcp latin1 -of rawvideo -mpegopts format=mpeg1:tsaf:muxrate=2000 -o \"" + video[n] + ".mpg\" -ovc lavc -lavcopts vcodec=mpeg1video:vbitrate=450:vpass=2:keyint=15:vmax_b_frames=2:mbd=2:aspect=4/3", UtilsPath);

                //if(StartProcess(UtilsPath + "sfdmux.exe", "-V=\"" + video[n] + ".mpg\" -A=\"" + video[n] + "-0.mp1\" -S=\"" + video[n] + "_2.SFD\"");

                File.Delete(video[n] + "-0.mp1");
                File.Delete(video[n] + "-0.m1v");

                //mencoder SP_01-0.m1v -sub lol2.srt -font calibri.ttf -subcp latin1 -of rawvideo -mpegopts format=mpeg1:tsaf:muxrate=2000 -o output.mpg -ovc lavc -lavcopts vcodec=mpeg1video:vbitrate=600:keyint=15:mbd=2:aspect=4/3

            }
            //File.Delete(video[n] + ".SFD");
            //File.Move(video[n] + "_2.SFD", video[n] + ".SFD");

            //File.Delete(video[n] + "-0.log");

            //File.Delete(video[n] + ".mpg");
        }*/

        private void button7_Click(object sender, EventArgs e)
        {
            About about = new About();
            about.ShowDialog();
        }
    }
}
