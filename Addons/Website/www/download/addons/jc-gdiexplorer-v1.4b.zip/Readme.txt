______________________________________________

 GDI Explorer - v1.4 beta
		   by japanese_cake 2010, 2011
______________________________________________


[+] What is GDI Explorer?
    ~~~~~~~~~~~~~~~~~~~~~
    
	GDI Explorer is a small tool that enables you to extract data
	from *.gdi files. It works with both NAOMI and DREAMCAST images.

	Features:
	 - Browse Dreamcast and Naomi GDI files
	 - Extract files (IP.BIN and IP0000.BIN included)
	 - Generate the "sorttxt.txt" file for mkisofs ("mkisofs [params] -sort sorttxt.txt")
	 - Convert GD-DA (raw audio tracks) to CD-DA
	 - Decrypt Naomi binary (see note)
	 - Create CUE file for mounting images in a virtual drive.


	If you have any ideas for features or improvements, feel free to contact me!

	DotNet framework 3.5 is required.


[+] THANKS TO:
    ~~~~~~~~~~

 - Deunan from dknute.livejournal.com for his help concerning DES decryption.


[+] NOTES
    ~~~~~

 - In some game ISOs, there are file names that ends by a dot ".". After extraction, those file names
   don't have this dot anymore.
   Example: in "Skies of Arcadia" ISOs, the file "DISK1." will be named "DISK" after extraction.
   
   The .Net Framework follows the Win32 naming conventions which do not authorize file name ending
   with a dot. A workaround exists however. All you need to do is to rename the file yourself using
   a shell command as below:
   C:\Dreamcast\SOA\>move DISK "\\?\DISK."

 - This is a beta version of GDI Explorer 1.4. Many bugs have been fixed, but there may still some
   that I haven't found yet.
   In addition, GDI loading times are longer than before, probably too long, specially for images which
   contain lots of files and directories. This is due to an implementation mistake I made. The next
   version will improve that, I promise ;)

 - Naomi PIC DES keys can be found at guru.mameworld.info/naomi/index.html.


[+] TODO
    ~~~~

 - Improve loading times
 - Drag & drop to desktop for file extraction/conversion
 - Command line support
 - Converting GDDA from an external file
 - A more friendly IP.BIN and PVD viewer
 - Files preview (GDDA/ADX/PVR/1ST_READ.BIN)
 - Prepare for backup feature
 - CRC/MD5/SHA1 checksums support
 - Localization support
 - Any ideas ?


[+] HISTORY:
    ~~~~~~~~

v1.4 beta (2011/12/07):
 - Added: Now support reading compressed GDI archives (ZIP) but
          it can still not extract data from them.
 - Fixed: Cannot parse GDI file with tabulation chars.
 - Fixed: Unable to extract directories when their relative name
          is like another ones in an highest path.
 - Fixed: The 2 seconds pause at the end of each CD-DA tracks is
          not well removed.
 - Fixed: An extracted directory datetime do not match with iso
          datetime.
 - Fixed: File association does not support long filenames.
 - Fixed: The UI does not clean some fields when a loading error
          occures.
 - Fixed: The right-click menu option "Convert all GDDA" appears
          even if there is no GDDA track.
 - Cleanup: UI's code and debugging information
  
v1.3.0.1 - beta to v1.3.1.2 (2010/09/08):
 - Fixed: Some loading errors
 - Fixed: Create a folder "trackXX" while extracting a data track
 - Added: Open a save dialog box while extrating a file
 - Added: Auto-paste PIC DES key if presents in the clipboard
 - Cleanup: GDIUtils's code

v1.2 to v1.3.0.1 - beta (2010/09/07):
 - Fixed: Less memory consumption while extracting files
 - Fixed: Clean up some parts of code
 - Fixed: Do not count directories in the session information frame
 - Fixed: Do not highlight Naomi bootfile in file list
 - Fixed: Crash when converting CDDA if the session does not have one
 - Added: Ask for a prefix while generating the "sorttxt.txt" file
 - Added: Can decrypt a Naomi binary (need a PIC DES key per game)
          from an external file or from a file inside a GDI image

v1.1.3 to v1.2 (2010/07/04):
 - Removed: GDI2CUE Converter (not useful anymore)
 - Added: Allow columns sorting in the list view
 - Added: Extract bootstrap when extracting the whole disc
 - Added: File loading improvements
 - Added: GDDA to CDDA conversion (using the tree view or
          conversion menu)
 - Added: Highlight bootfile in file list
 - Added: CUE file export

v1.1.2 to v1.1.3 (2010/06/11):
 - Fixed: After extraction, some files are corrupted
 - Fixed: Disc tree navigation don't show the current opened
          directory
 - Added: Show GDDA tracks
 - Added: Drag & drop with .gdi files

v1.1 fixed to v1.1.2 (2010/03/11):
 - Added: IP.BIN & IP0000.BIN extraction.
 - Added: Messagebox after extracting the boot file or
          the sorttxt.txt file.
 - Added: Newer version of GDI2CUE Converter (v1.3.0.1)

v1.1 to v1.1 fixed (2010/03/04):
 - Fixed: Cannot extract multiple files
 - Fixed: Association button crashes programs
 - Fixed: Unhandled WinForms exceptions
 - Added: The sorttxt.txt file generation
 - Added: An icon when GDI files are associated with GDI Explorer
 - Added: New explorer icons

v1.0b to v1.1 (2010/02/20):
 - Improved: Exception handling
 - Fixed: File access date.
 - Fixed: Extracting process failed when an app is reading a file/dir
 - Fixed: Extracting progress-bar doesn't count correctly
 - Added: Loading window
 - Added: List multiple selection
 - Added: You can now associate *.gdi files with GDI Explorer
 - Added: A GDI file icon

v1.0b :
 - First public beta

______________________________________________

                            jc.dcdev@gmail.com
                 japanese-cake.livejournal.com
______________________________________________
