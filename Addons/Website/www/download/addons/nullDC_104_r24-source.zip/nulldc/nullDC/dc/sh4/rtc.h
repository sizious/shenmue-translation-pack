#pragma once

#include "types.h"

//Init/Res/Term
void rtc_Init();
void rtc_Reset(bool Manual);
void rtc_Term();