#include "types.h"
#include "dc/mem/sh4_internal_reg.h"
#include "sci.h"


//Init term res
void sci_Init()
{
}
void sci_Reset(bool Manual)
{
}
void sci_Term()
{
}