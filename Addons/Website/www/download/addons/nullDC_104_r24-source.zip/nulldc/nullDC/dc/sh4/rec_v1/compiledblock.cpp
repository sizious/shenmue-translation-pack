//Compiled block code
//ALL OF IT WILL COME HERE !

#include "compiledblock.h"
#include "basicblock.h"

