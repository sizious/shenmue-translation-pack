#pragma once
bool ParseCommandLine(int argc,wchar* argv[]);