#pragma once
#include "nullAICA.h"

void ds_InitAudio();
void ds_TermAudio();

void ds2_InitAudio();
void ds2_TermAudio();