//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by drkMapleDevices.rc
//
#define IDD_ConfigKeys                  101
#define IDD_VMU                         102
#define IDD_LCD                         102
#define IDD_DIALOG1                     103
#define IDC_PORTTAB                     1002
#define IDC_BUTTON1                     1007
#define IDC_BUTTON2                     1008
#define IDC_BUTTON3                     1009
#define IDC_BUTTON4                     1010
#define IDC_BUTTON5                     1011
#define IDC_BUTTON6                     1012
#define IDC_BUTTON7                     1013
#define IDC_BUTTON8                     1014
#define IDC_BUTTON9                     1015
#define IDC_BUTTON10                    1016
#define IDC_BUTTON11                    1017
#define IDC_BUTTON12                    1018
#define IDC_BUTTON13                    1019
#define IDC_STATUS                      1020
#define IDC_BUTTON14                    1021
#define IDC_BUTTON15                    1022
#define IDC_BUTTON16                    1023
#define IDC_NAOMI_UP_KEY                1023
#define IDC_BUTTON17                    1024
#define IDC_NAOMI_LEFT_KEY              1024
#define IDC_BUTTON18                    1025
#define IDC_BUTTON19                    1026
#define IDC_BUTTON20                    1027
#define IDC_NAOMI_RIGHT_KEY             1027
#define IDC_BUTTON21                    1028
#define IDC_NAOMI_DOWN_KEY              1028
#define IDC_BUTTON22                    1029
#define IDC_NAOMI_BTN0_KEY              1029
#define IDC_BUTTON23                    1030
#define IDC_NAOMI_BTN1_KEY              1030
#define IDC_NAOMI_BTN2_KEY              1031
#define IDC_NAOMI_BTN3_KEY              1032
#define IDC_NAOMI_BTN4_KEY              1033
#define IDC_NAOMI_BTN5_KEY              1034
#define IDC_NAOMI_START_KEY             1035
#define IDC_NAOMI_COIN_KEY              1036
#define IDC_NAOMI_SERVICE_KEY_1         1037
#define IDC_NAOMI_TEST_KEY_1            1038
#define IDC_NAOMI_SERVICE_KEY_2         1039
#define IDC_NAOMI_TEST_KEY_2            1040

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
