class MapleDevice
{
};
