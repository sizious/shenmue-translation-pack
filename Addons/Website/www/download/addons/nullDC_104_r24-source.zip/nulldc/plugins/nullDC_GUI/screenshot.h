#include <windows.h>
bool Screenshot(LPCTSTR FileName, HWND hwnd);