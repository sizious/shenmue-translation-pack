//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PuruPuru.rc
//
#define IDD_CONFIG                      101
#define IDB_BITMAP1                     104
#define IDD_ABOUT                       105
#define IDB_BITMAP2                     106
#define IDC_JOYNAME                     1001
#define IDC_JOYATTACH                   1002
#define IDC_SHOULDERL                   1010
#define IDC_SHOULDERR                   1011
#define IDC_A                           1012
#define IDC_B                           1013
#define IDC_X                           1014
#define IDC_Y                           1015
#define IDC_START                       1016
#define IDC_DPAD                        1017
#define IDC_MX                          1018
#define IDC_MY                          1019
#define IDC_DEADZONE                    1020
#define IDC_HALFPRESS                   1021
#define IDC_ABOUT1                      1021
#define IDC_DPAD_DOWN                   1022
#define IDC_ABOUT3                      1022
#define IDC_DPAD_LEFT                   1023
#define IDC_STATEI                      1023
#define IDC_DPAD_RIGHT                  1024
#define IDC_CONTROLTYPE                 1025
#define IDC_BUTTON1                     1026
#define IDABOUT                         1026
#define IDC_DPAD_TEXT1                  1037
#define IDC_DPAD_TEXT2                  1038
#define IDC_DPAD_TEXT3                  1039
#define IDC_DPAD_TEXT4                  1040
#define IDTEXT_SHOULDERL                2010
#define IDTEXT_SHOULDERR                2011
#define IDTEXT_A                        2012
#define IDTEXT_B                        2013
#define IDTEXT_X                        2014
#define IDTEXT_Y                        2015
#define IDTEXT_START                    2016
#define IDTEXT_DPAD                     2017
#define IDTEXT_MX                       2018
#define IDTEXT_MY                       2019
#define IDTEXT_HALFPRESS                2021
#define IDTEXT_DPAD_DOWN                2022
#define IDTEXT_DPAD_LEFT                2023
#define IDTEXT_DPAD_RIGHT               2024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
