//////////////////////////////////////////////////////////////////////////////
// Mapping:
//////////////////////////////////////////////////////////////////////////////
Controller:
obvious
______________________________________________________________________________
Twinstick:
joysticks: joysticks
joystick buttons: joystick "clicks"
joystick triggers: triggers
Start: start
D (pause): back

As this is only used in virtual on, i think it's ok to use this mapping.

In case you're wondering, the literal mapping is:
A: right trigger
B: right joystick "click"
X: left trigger
Y: left joystick "click"
______________________________________________________________________________
Arcade:
A, B, X, Y, start, joystick: obvious
C: left bumper
Z: right bumper

I am open to suggestions for this mapping

//////////////////////////////////////////////////////////////////////////////
// Infos:
//////////////////////////////////////////////////////////////////////////////
Things left to do (besides adding DInput ;))
1) Bug squashing!
I need SHOE to find bugs! :p

2) Rumble...
If a game spams rumble (Under Defeat), emulation can sloowowww down... :(