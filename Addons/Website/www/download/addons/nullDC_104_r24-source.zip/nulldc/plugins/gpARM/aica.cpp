#include "aica.h"
#include <math.h>




//Mainloop
void FASTCALL UpdateARM(u32 Cycles)
{
}
