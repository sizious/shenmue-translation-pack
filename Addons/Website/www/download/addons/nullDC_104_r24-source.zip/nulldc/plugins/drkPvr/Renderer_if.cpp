#include "Renderer_if.h"
#include "nullRend.h"
#include "d3dRend.h"

u32 VertexCount=0;
u32 FrameCount=0;
