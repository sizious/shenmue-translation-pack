#include "lan.h"
/*
	Huh, i used to have code in here o.O
	Ohh well, nothing to be missed
*/

u32 FASTCALL LanReadMem_A0_006(u32 addr,u32 size)
{
	return 0;
}
void FASTCALL LanWriteMem_A0_006(u32 addr,u32 data,u32 size)
{
}