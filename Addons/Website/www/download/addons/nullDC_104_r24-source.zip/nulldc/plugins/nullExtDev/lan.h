#pragma once
#include "nullExtDev.h"

u32 FASTCALL LanReadMem_A0_006(u32 addr,u32 size);
void FASTCALL LanWriteMem_A0_006(u32 addr,u32 data,u32 size);