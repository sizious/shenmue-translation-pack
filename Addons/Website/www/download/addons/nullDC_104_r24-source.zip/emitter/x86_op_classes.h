#pragma once

//auto generated
enum x86_opcode_class
{
	#include "generated_class_names.h"

	////////
	op_count,
};