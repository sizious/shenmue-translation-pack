Tools are provided AS IS, there is no documentation for most, half them have
no understandble UI and many may not even work as I had custom stuff in the
source pointing to specific folders and what not.

Don't ask me how they work or even what they do.

Have fun!

ADXConverter

Convert between ADX <-> SFA

ADXLoopCalculator

Calculate loop points for adxencd after downsample

ADXSorter

Sort ADX by mono/stereo and sample rate

AFSCompactor

Compact AFS files (remove reserved index data at beginning of file)

AFSExtractor

Extract AFS, only auto-detected formats are ADX, AHX and PVR

AFSLinker

Create AFS file from ALS (which is just a plain text file with filenames)

CDDAPatcher

Hack KATANA binaries for CDDA

CDFSInformationCopier

Copy useless info from one source to another (preserve timestamps, volume
label etc.)

CRIAudioSplitter

Split ADX files into left/right streams

DummyHider

Hide dummy file 0.0 in CD file system

ISOJoiner

Joins the output of fixed.iso (isofix track03.iso) and last data track after
CDDA files to a new fixed.iso of full size which files can be extracted from

LBAConverter

Convert LBA to MSF format (useless)

makesort

Change ISOBuster FileList.txt to a sorttxt.txt file

MultipleFileLBACopier

Hacks multiple LBAs based on their CRC32 match, forgotten how it works

SilenceTrim

Trims silence from start/end of WAV/RAW files (makes more space for CDDA rips)

SingleFileLBACopier

If you have dupe files, overwrite one with a 0 byte file and then you can use
this to transparently "link" them to the same data in ISO

SorttxtIndexer

Takes a standard file list and outputs it in sorttxt format