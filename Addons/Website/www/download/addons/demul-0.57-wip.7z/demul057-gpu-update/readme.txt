DX11 Plugin with Internal Render Scaler for DEmul x86 v0.57
