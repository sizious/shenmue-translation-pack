# =====================================================================================================
# Preliminary DTPK--->DSF converter (ver 0.01 2008-11-02) by kingshriek
# This script only supports the AM2 DTPK sound driver and not necessarily all the different versions 
# of it.
# The script is set up by default to ignore sound effect data and only process actual sequenced music.
# Update history located near end of file
# =====================================================================================================

# =====================================================================================================
import os
import sys
import zlib
from struct import pack,unpack 
from array import array
from glob import glob
from copy import copy
# =====================================================================================================

# =====================================================================================================
# Convert RAM image to DSF format
def bin2dsf(nout, dsfbin, load=0, tagdict={}):
	dsfz = zlib.compress(array('B', pack('<I', load)) + dsfbin)
	sig = 'PSF' + '\x12'
	res = pack('<I', 0)
	size = pack('<I', len(dsfz))
	crc = pack('<i', zlib.crc32(dsfz))
	if tagdict:
		tag = '[TAG]'
		for field in tagdict:
			tag += '%s=%s\x0A' % (field, tagdict[field])
	else:
		tag = ''
	open(nout, 'wb').write(sig+res+size+crc+dsfz+tag)
# ====================================================================================================

# =====================================================================================================
# Create dsf using DTPK file
def dsfdtpk(nout,ndrv,ndtpk,track=None,doall=False):
	# Read in driver file
	dsfbin = array('B', '\x00'*0x10000)
	ddrv = array('B', open(ndrv, 'rb').read())
	szdrv = len(ddrv)
	dsfbin[0:szdrv] = ddrv
	
	# Read in DTPK file
	ddtpk = array('B', open(ndtpk, 'rb').read())
	if ddtpk[:4].tostring() != 'DTPK':
		print 'Skipping %s - not a valid DTPK sound file' % ndtpk
		return
	dsfbin += ddtpk
	
	# Configure driver for either Dreamcast or Naomi
	if len(dsfbin) > 0x1FE000:
		dsfbin[0x50:0x54] = array('B', pack('<I', 0x200))    # set driver config to Naomi if > than 2 MB needed
		
	# Set up sound map
	bank = 0
	dtpk_id = unpack('<I', ddtpk[4:8])[0]
	dsfbin[0x60+bank*4:0x64+bank*4] = array('B', pack('<I', dtpk_id))   # Map bank to DTPK id
	
	# Determine bank command
	bank_cmd = 0xA0001100 | bank
	
	# Determine sequence command(s)
	seq_offset = unpack('<I', ddtpk[0x2C:0x30])[0]
	if not seq_offset:
		print 'Skipping %s - no sequence data found' % ndtpk
		return
		
	ncmds = unpack('<I', ddtpk[seq_offset:seq_offset+4])[0] + 1
	seq_cmds = []
	seq_offset += 4
	for icmd in range(ncmds):
		seq_cmds.append(unpack('<I', ddtpk[seq_offset:seq_offset+4])[0] & 0xFFFF0000)
		seq_offset += 4
		
	# Skip processing if sound effects/other data detected and user doesn't want them
	if not doall and all([(seq_cmd>>24) != 0xA8 for seq_cmd in seq_cmds]):
		print 'Skipping %s - sound effects or other data' % ndtpk
		return
		
	for seq_cmd in seq_cmds:
		if track:
			seq_cmd |= (track << 8)
		
		# Write sound commands
		cmd_offset = 0x400
		dsfbin[0x400:0x404] = array('B', pack('>I', bank_cmd))    # Register DTPK bank
		if doall or (seq_cmd>>24) == 0xA8:
			dsfbin[0x404:0x408] = array('B', pack('>I', seq_cmd))     # Play sequence
	
	# Get number of tracks
	ntracks = unpack('<I', ddtpk[seq_offset:seq_offset+4])[0] + 1
	
	# Create DSF or miniDSFs based on number of tracks
	print 'Converting %s...' % ndtpk
	if (len(seq_cmds) == 1 and ntracks == 1) or track != None:
		seq_cmd = seq_cmds[0]
		print '\tCreating %s (bank_cmd %08X seq_cmd %08X)' % (nout, bank_cmd, seq_cmd)
		bin2dsf(nout,dsfbin)
		
	else:
		(xout, eout) = os.path.splitext(nout)
		nout = xout + '.dsflib'
		print '\tCreating %s' % nout
		bin2dsf(nout,dsfbin)
		
		tagdict = {'_lib': nout}    # Tag data that points minidsfs to the dsflib
		for icmd, seq_cmd in enumerate(seq_cmds):
			if not doall and (seq_cmd >> 24) != 0xA8:
				continue
			for itrack in range(ntracks):
				seq_cmd = (seq_cmd & 0xFFFF0000) | (itrack << 8)   # Include track number in sequence command
				trackbin = array('B', pack('>I', seq_cmd))
				load = 0x404
				nout = xout + '_%02d_%02d.minidsf' % (icmd, itrack)
				print '\tCreating %s (bank_cmd %08X seq_cmd %08X)' % (nout, bank_cmd, seq_cmd)
				bin2dsf(nout,trackbin,load,tagdict)

# =====================================================================================================

# =====================================================================================================
if __name__ == '__main__':
	argv = sys.argv
	argc = len(argv)
	default_flags = {'a':0, 't':0}
	default_params = {'track': None, 'doall': False}
	if argc < 2:
		print 'AM2 DTPK DSF script v0.01 by kingshriek'
		print 'Usage: python %s <DTPK sound driver> [options] <DTPK sound files...>' % argv[0]
		print 'Options:'
		print '          -a       include sound effects and other sound data'
		print '          -t <n>   disable automatic minidsf creation and create a single dsf with specified track number'
		print '          --       turn all previous flags off'
		sys.exit(0)
		
	ndrv = argv[1]
	
	flags = copy(default_flags)
	params = copy(default_params)
	
	for arg in argv[2:]:	
	
		if flags['a']:
			params['doall'] = True
			flags['a'] = 0
			
		if flags['t']:
			params['track'] = int(arg)
			flags['t'] = 0
			continue
				
		if arg[0] == '-':
			flag = arg[1:]
			if flag in flags:
				flags[flag] = 1
			elif flag == '-':
				flags = copy(default_flags)
				params = copy(default_params)
			else:
				print 'Error: Invalid option -%s' % flag
				sys.exit(1)
		else:
			ndtpks = glob(arg)
			for ndtpk in ndtpks:
				(xdtpk, edtpk) = os.path.splitext(ndtpk)
				nout = xdtpk + '.dsf'
				dsfdtpk(nout,ndrv,ndtpk,**params)
# =====================================================================================================

# =====================================================================================================
# 08-11-02 (0.01) - Fixed script so that it pulls BGM from hybrid sound files (w/ mixed commands) with
#                   default settings (it would previously skip the file).
# 08-10-31 (0.00) - Initial version.
# =====================================================================================================
	