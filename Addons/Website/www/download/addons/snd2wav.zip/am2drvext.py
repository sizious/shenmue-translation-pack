# =====================================================================================================
# Sega Dreamcast AM2 DTPK sound driver extractor v0.00 (2008-11-02) by kingshriek
# Dumps instances of AM2 DTPK sound driver images from an uncompressed archive.
# Version history located near end of file
# =====================================================================================================

# =====================================================================================================
import os
import sys
import mmap
from struct import *
from glob import *
# =====================================================================================================

# =====================================================================================================
SEARCH_STRING = 'AM2/AICA'
VER_STRING_OFFSET = 0x20
VER_STRING_LENGTH = 0x20
DRIVER_SIZE = 0x10000
# =====================================================================================================

# =====================================================================================================
def vector_table_sanity_check(vector_table):
	return all([byte=='\xEA' for byte in vector_table[3:0x20:4]])
# =====================================================================================================

# =====================================================================================================
def drvext(finame,outdir):
	try:
		fi = open(finame,'rb')
	except:
		return -1
	fisz  = os.path.getsize(finame)
	fimap = mmap.mmap(fi.fileno(),fisz,access=mmap.ACCESS_READ)
# -----------------------------------------------------------------------------------------------------
	fibase = os.path.basename(finame)
	idot  = -fibase[::-1].find('.')-1
	if idot:
		finoext = fibase[:idot]
	else:
		finoext = fibase
# -----------------------------------------------------------------------------------------------------
	offset = VER_STRING_OFFSET
	idx = 0
	while offset < fisz:
		offset = fimap.find(SEARCH_STRING, offset)
		if offset >= 0:
			vector_table = fimap[offset-VER_STRING_OFFSET:offset]
			ver_string = fimap[offset:offset+VER_STRING_LENGTH]
			if vector_table_sanity_check(vector_table):
				offset -= VER_STRING_OFFSET
				foname = finoext + '_%02d.drv' % idx
				print '[%08X] %s (%s)' % (offset, foname, ver_string.strip())
				open(os.path.join(outdir,foname), 'wb').write(fimap[offset:offset+DRIVER_SIZE])
				idx += 1
				offset += DRIVER_SIZE
			else:
				offset += 1
		else:
			break
# -----------------------------------------------------------------------------------------------------
	fimap.close()
	fi.close()
	return
# =====================================================================================================

# =====================================================================================================
if __name__ == '__main__':
	argv = sys.argv
	argc = len(argv)
	if argc < 3:
		print 'Sega AM2 DTPK sound driver extractor v0.00 by kingshriek'
		print 'Usage: python %s <filename(s)> <output directory>' % argv[0]
		sys.exit()
	outdir = argv[-1]
	if not os.path.exists(outdir):
		os.mkdir(outdir)
	for arg in argv[1:-1]:
		finames = glob(arg)
		for finame in finames:
			drvext(finame,outdir)
# =====================================================================================================

# =====================================================================================================
# 08-11-02 (0.00) - Initial version.
# =====================================================================================================
