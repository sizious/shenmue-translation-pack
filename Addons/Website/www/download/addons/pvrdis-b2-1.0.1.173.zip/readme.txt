Thank you for downloading/installing this program.

There are a few things you need to know before you run or use the program.

1) This release is a beta version. Take the program for what it is, not what it should be. That's what updates are for. :)

2) *PLEASE* report any bugs you find to my e-mail address. If you have a suggestion or any comments, use the same address. (but do not forget to mention the subject of your message or it will be DELETED)

3) Enjoy! You can get pretty interesting stuff from games, using this.

------------------
KNOWN BUGS
------------------------------

1) The program may suddenly stop working just when it finishes processing a file. I believe this is part of a bigger conceptual problem I'm working on fixing...

Even though this is a very rare situation, you should be warned. If this happens... Well, you'll just have to start over, sorry, I can't help you there. Not even I am sure exactly what causes the extractor thread to lock. What can I say, I'm not too used to multi-threading like this. :/

All I can say for now is DON'T PLAY WITH THE PAUSE/ABORT BUTTONS! Pausing the process is fine, but avoid doing it too often.

------------------
STUFF TO BE:
------------------------------

1) New directory select dialog. (I hate the stupid and annoying built-in dialog, plus it induces a lot of new dependencies)

2) Converter. Yes, I know it already converts. I mean you being able to select a bunch of PVR files and converting them directly without going through the normal scan+extract+convert process. It should be *much* faster, since there is no scanning involved.

3) Make the process faster. Or try to, lol. This is still limited to the user's computer speed.

4) Cleaner code... It's truly messed up =P