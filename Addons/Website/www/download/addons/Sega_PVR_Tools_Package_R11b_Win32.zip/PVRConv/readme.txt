PVRConv requires textures to be 8x8 or larger.

If you require a smaller texture, create it within an 8x8 
bitmap and reference to the proper UV coordinates within 
the 8x8 bitmap.