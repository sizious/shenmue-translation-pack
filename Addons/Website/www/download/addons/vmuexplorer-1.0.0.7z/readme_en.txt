VMU Explorer 1.0.0 by Speud
speud@free.fr - http://blueswirl.shorturl.com


This program allows you to open VMU dumps made with
VMU Tool - Dream Explorer (.VMU, .DCM) or Chankast (VMS.BIN).
It supports raw VMU dumps as well as Nexus cards dumps.

The files list displays all info and bitmaps, all filetypes are supported (icons,
games, saves).
Eyecatches and (animated) icons are displayed correctly.
Description of each colon can be read by clicking the header.

You can see position of blocks used in the VMU for each file.
In green: selected file's blocks
In blue: selected file's last block
In red: other files' blocks
In gray: empty blocks

The VMUs are fully scanned and all the files found are displayed.
The only limit of the files list is the size of the VMU.

The menus let you open several VMUs at a time and manage their content freely.
You can defragment VMUs, reformat them, create new blank VMUs...
You can also copy/paste files from a VMU to another, fix bad CRC, import/export
files in DCI or VMI+VMS...

To avoid modifying your VMUs by accident, changes won't be saved to the VMUs
unless you select the save option.


To use VMU Explorer with Chankast's VMUs:
- place the vmuexplorer.exe and the vmuexplorer.bat files in Chankast's directory
- double click the vmuexplorer.bat file

To save the content of your VMU in a dump file:
- connect your DC to your PC with a BBA/coder's cable
- launch VMU Tool - Dream Explorer on your Dreamcast
- select the "open VMU" option
- select the source VMU
- select the "save dump" option
- select the path of the new dump file

To copy the dump back to your VMU:
- save the dump with a .VMU or a .DCM extension
- burn the file on a CD or connect your PC to your DC with a BBA/coder's cable
- launch VMU Tool - Dream Explorer on your Dreamcast
- select the "open CD/PC" option
- browse the directories to find your file
- select the "load dump" option
- select the destination VMU

