VMU Explorer 1.0.0 par Speud
speud@free.fr - http://blueswirl.shorturl.com


Ce programme vous permet d'ouvrir des dumps VMU faits avec
VMU Tool - Dream Explorer (.VMU, .DCM) ou Chankast (VMS.BIN).
Il supporte les dumps VMUs normaux ainsi que les dumps des cartes Nexus.

La liste des fichiers affiche toutes les infos et tous les bitmaps, tous les
types de fichiers sont support�s (icones, jeux, sauvegardes).
Les vignettes et les icones (anim�s) sont correctement affich�s.
Une description de chaque colonne peut �tre lue en cliquant l'en-t�te.

Les VMUs sont enti�rement scann�s et tous les fichiers trouv�s sont affich�s.
La seule limite de la liste de fichiers est la taille du VMU.

Vous pouvez voir la position des blocs utilis�s dans le VMU pour chaque fichier.
En vert: les blocs du fichier s�lectionn�
En bleu: le dernier bloc du fichier s�lectionn�
En rouge: les blocs des autres fichiers
En gris: les blocs vides

Les menus vous laissent ouvrir plusieurs VMUs � la fois et vous occuper de leur
contenu librement.
Vous pouvez d�fragmenter les VMUs, les reformatter, cr�er de nouveaux VMUs vides...
Vous pouvez aussi copier/coller des fichiers d'un VMU � un autre, corriger les
mauvais CRC, importer/exporter des fichiers en DCI ou VMI+VMS...

Pour �viter de modifier vos VMUs par accident, les changements ne seront pas
enregistr�s sur les VMUs � moins que vous choisissiez l'option d'enregistrement.


Pour utiliser VMU Explorer avec les VMUs de Chankast:
- placer les fichiers vmuexplorer.exe et vmuexplorer.bat dans le dossier de Chankast
- double cliquer le fichier vmuexplorer.bat

Pour enregistrer le contenu de votre VMU dans un fichier dump:
- relier votre DC � votre PC avec un BBA/coder's cable
- lancer VMU Tool - Dream Explorer sur votre Dreamcast
- choisir l'option "ouvrir VMU"
- choisir le VMU source
- choisir l'option "enregistrer dump"
- choisir le chemin du nouveau fichier dump

Pour recopier le dump vers votre VMU:
- enregistrer le dump avec une extension .VMU ou .DCM
- graver le fichier sur un CD ou relier votre PC � votre DC avec un BBA/coder's cable
- lancer VMU Tool - Dream Explorer sur votre Dreamcast
- choisir l'option "open CD/PC"
- parcourir les dossiers pour trouver votre fichier
- choisir l'option "charger dump"
- choisir le VMU de destination

