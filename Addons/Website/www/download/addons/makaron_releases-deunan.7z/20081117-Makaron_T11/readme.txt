Makaron T11/1
--

UPDATE: Makaron T11/1 is out.
You can grab it from RapidShare. It seems they now have a download limit system - so in case it kicks in you can try SendSpace as an alternative.

Now, pay attention:
* It's only the Dreamcast version for now.
* It has been compiled with Microsoft Visual C++ so you might need to install the runtime libraries to get it to work. It's only 4MB and you can download it from Microsoft.
* Hit F8 to exit the emulator at any time
* You can now use Pause/Break key to pause/resume the emulation

Minimum hardware requirements have also changed:
* Processor must have SSE support
* Graphics card must be at least Shader Model 2.0 compatible

By not having to support ancient Pentium 2s and Durons, and Radeon 8500, I can make the code simpler and maybe a bit faster too. That old hardware wasn't going to run Makaron at any acceptable speeds anyway :)

Source: http://dknute.livejournal.com/23109.html