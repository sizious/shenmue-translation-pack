Makaron T10
--

At least some of you must realize that developing Makaron is a time consuming process. Time I could very well be spending doing things that bring me money. I have expenses you know, mostly PC hardware and software but also Dreamcast games and other stuff (like a new oscilloscope, as the old one died on me sometime ago).
I'm happy people use my emulator and find it useful, but I also belive it's only fair I got someting out of it as well.

Having said that I've came up with an idea of Pay to Play system for Makaron - prepaid style. Makaron will be free to download and try out but to play longer you will need to purchase an activation code. Simply put, in exchange for money you'll be given a limited time to use my emulator. Once that time is up you'll need to pay again, very much like you would for a cell phone number.
Payment options will include credit cards and other common money transfer services, but I haven't yet decided on the rates so it'll take a few days to set everyting up. I will be done with the activation code shortly too.

This is the last free version: Makaron T10.

UPDATE: I've changed my mind - I'm going to start with payment system right now. If you've managed to download the free T10 then consider yourself lucky.

Source: http://dknute.livejournal.com/18488.html