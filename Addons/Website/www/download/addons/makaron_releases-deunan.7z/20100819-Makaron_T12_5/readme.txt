Makaron Test 12/5
--

UPDATE: Here it is, Test 12/5. There's a small ReadMe included so be sure to read it. No Atomiswave yet since I didn't think T12 core could be salvaged, so I didn't bother with it. I wasn't exactly wrong there, with all the changes I made this version could easily be called Test 13 :)

Anyway, other things of note (from the top of my head):
* Current renderer needs to go. I have a replacement of sorts prepared, as a part of software renderer project. I'm pretty sure it will be a bit slower but that remains to be seen. I need the new framework anyway to support both D3D9 and D3D11 at the same time.
* SH4 recompiler could use some sort of abstraction layer to handle the optimizations better. Again, it'd probably end up being marginally slower but more manageable and could in future be paired with x64 emitter.
* I'm going to drop support for non-SSE2 CPUs soon, mostly because it'd be easier to code the new recompiler. Quite frankly any CPU without SSE2 is not going to be fast enough to handle Makaron anyway.
* Windows XP and Direct3D 9 support is going to stay for now but once D3D11 renderer starts working properly I will focus mostly on that. While I realize that droping DX9 will upset XP users, I'd like to point out that Makaron always required a modern PC. I havent introduced any major changes lately but before that Makaron was the first Dreamcast emulator to require shaders, then it would work only with Shader Model 2 or higher. In return you got faster palletized texture support, shadows and fogging. Now it's going to be DirectX 11 :)


EDIT: Seems like 640x240 interlaced modes are not upscaled properly. One way around it is to change cable type to VGA. If the game doesn't support VGA cable you're out of luck, use mode 4 or just go back to 640x480. This should never happen on NAOMI since by default it runs in 31k setting. I fixed that already but I'm not pulling the files unless there is a bug that can't be worked around.


UPDATE 2: That bug I wrote about? Now you're seeing it's effects first-hand :) Oh well, guess I better fix that one since I didn't add an option to skip DX11 init.
Redownload T12/5 from here, this time when Direct3D 11 is present on the system but actual device can't be created it will just silently ignore the problem. This was the intention after all. And I also added workaround for the scaler issue.

Source: http://dknute.livejournal.com/34884.html