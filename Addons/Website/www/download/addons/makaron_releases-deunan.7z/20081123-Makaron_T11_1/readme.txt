Makaron T11/1
--

New version awaits you on SendSpace :)

This time the package includes NAOMI emulator as well. And I've modified the code a bit, let's hope this will make the Data Execution Prevention exception go away.
Both executables can now reside in the same directory, but because of that there are some minor changes:
* Dreamcast BIOS/FLASH filenames must now start with Dreamcast_ prefix.
* NAOMI BIOS filenames must start with NAOMI_ prefix.
* The main configuration file for NAOMI emulator is now called NAOMI.ini

And yes, you still need to extract and decrypt any NAOMI games you wish to run from the GDI image. It's also possible to extract them from CHD files.

Remember to install the runtime libraries for MSVC 2008 SP1 if you get those silly "not installed correctly" errors.


UPDATE: It seems I forgot to put the newly compiled Makaron executable into the package. Sorry :)
Redownload, I've updated the link. Also, if you add "aniso = 0" to the Settings section it should disable anisotropic filtering. Not really tested.


UPDATE 2: To clear some confusion - executables in the package are the MT (multi-threaded) ones, even if the names don't suggest it. I don't think I will be making separate ones for single core/CPU systems anymore. There are several reasons behind it:
1) More and more people have multi-core PCs now (they don't even sell E6600 anymore!)
2) MSVC links against MT libraries by default (probably because of (1), not to mention single-threaded versions are kinda frowned upon)
3) MT executables can still be run on single-core systems (the performance drop due to locking used isn't that big and frankly older PCs struggle with Makaron anyway)
4) I have 2-core CPU myself so obviously I want to use its full potential whenever possible (I actively develp Makaron that way, so testing non-MT version is a waste of my time)

If in doubt, check the debug output window or the logfile. It should say "Version Test 11/1 (MT)".

Also, there is a silly bug that causes the FLASH files to be written back to disk without the "Dreamcast_" prefix. Keep that in mind in case you're unable to set the clock properly - you will need to rename the file yourself. I already fixed this so it will work as expected in next version. And yes, the digital filering isn't yet perfect as it seems to mute BIOS menu sounds too much.

Source: http://dknute.livejournal.com/23543.html