Makaron T10/1
--

Well, this isn't the surprise I was talking about but it's still better than nothing :)
Makaron Test 10/1 is out. You know the drill.

T9/4 and T10 were rather unstable but this time around I'm more happy with both GD and DMA code. It's not just bugfixes though, there are several new features in this version:
- support for VMU sounds
- improved Z-buffering
- fully functional DSP
- experimental anisotropic filtering

DSP is enabled by default. It might slow down things a bit, though (as usual) if you have a fast C2D you won't notice it. I'm really considering running whole AICA on separate thread now by the way, so it should improve in future for multi-core systems.
Please note that there's a slight slowdown noticable (in audio) when sequenced music is being played, in all Makaron versions released so far. This is sort of design flaw (and due to rather demanding hardware setup) and will be someday corrected.

Anisotropic filtering is too enabled by default, to 8x - it will be scaled down if your card can't support such mode. This will only be a problem for those cheap cards that support AFx8 but are very slow at it, in this case you might get quite a performance drop. If this becomes an issuse I'll tell you how to disable AF :)

Source: http://dknute.livejournal.com/21417.html