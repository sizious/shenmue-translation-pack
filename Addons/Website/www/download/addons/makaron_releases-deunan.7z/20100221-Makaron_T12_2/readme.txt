Makaron T12/2
--

NAOMI Test 12/2 is here.
This is just a few tweaks and changes added to the old T12 core - I'm still working on new version and that's not yet ready. The reason I'm releasing T12/2 is the addition of code, written by Andreas Naive, that allows run-time M2/M3 decryption of NAOMI carts without having to rely on trojaned out protection data.
Once the game key is obtained for a given cart - and this is done with another trojan and some smart analysis (Andreas approach) or brute forcing (cough) - all data can be derived directly from the encrypted parts.

I've added a simple ZIP handler and now you can load some of MAME games:
"Capcom vs. SNK", "Cosmic Smash", "Gun Spike" / "Cannon Spike", "Dead or Alive 2" / "Dead or Alive 2 Millenium", "Giga Wing 2", "Giant Gram 2000", "Heavy Metal Geomatrix", "Marvel vs Capcom 2", "Moero Justice Gakuen" / "Project Justice", "Power Stone", "Power Stone 2", "Toy Figher", "Virtua Tennis", "WWF Royal Rumble".
More MAME images will be supported in future.

Some titles still need the protection data to be present because M1 and compressed M2/M3 variants are not yet supported by the decoder. You will get a nice error message if any required files are missing :)

Oh, the decoder works only for MAME images at this point. The plain images will need some game detection code to properly set the keys.


UPDATE: Yup, apparently Sendspace guys don't like Makaron. Or emulators in general. They deleted the file citing terms of use violation. I will upload T12/2 to another place but this gives me opportunity to add support for a few more MAME images so please wait a bit.

UPDATE2: Updated version is now available.
- "Toy Fighter" off-by-one bug fixed
- "Giant Gram 2000" will now load (but won't work due to missing M1 data)
- "Virtua NBA" added (though the "virnbao" version will not work, this one seems protected?)
- "Samba De Amigo" added (I'm not saying it's playable mind you)
- "Guilty Gear X" _would_ work if not for a truncated protection file (but here's a hint, unpack ggx.zip, add zeros to the file to match required length and pack it again and it will work now)
- "Dead or Alive 2 Millenium" will now properly load parent ROM (same goes for other games with variants)
- "18 Wheeler" added (not tested)
- "Crazy Taxi" added (not tested)
- "Death Crimson OX" added

Source: http://dknute.livejournal.com/31129.html