Makaron Test 8 Work-in-Progress
--

It's just a preview of sorts, whether you'll be able to use it to run games is not really my problem. It's here just to show how far this project has advanced, nothing more. There's a ReadMe inside that package and that's it - I'll provide no help for it, you're on your own.

Use the "MT" executable on multiple-core systems for better speed.

Source: http://dknute.livejournal.com/10715.html