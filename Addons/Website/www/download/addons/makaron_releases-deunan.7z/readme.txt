Makaron Test Releases
--

Here is the Makaron releases in one single package.

Most of them are coming from a Russian website that I lost the URL.
So feel free to contact me to put the original link in this package.
The original archive name is "Old_Makarons.7z".

I scanned the whole Deunan blog to get the Makaron history.
The URL is : http://dknute.livejournal.com/

I'm missing the following releases:
- T12/2
- T12/3

I was unable to find the release date of the T11/2.

Enjoy.

SiZ!
