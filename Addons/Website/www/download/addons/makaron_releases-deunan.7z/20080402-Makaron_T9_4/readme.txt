Makaron Test 9/4
--

UPDATE: Makaron Test 9/4 for those who like to experiment.
I'd urge you to wait for T10 as this is a bastard mix of current (broken) dev and older T9/2. I got it to compile and run but that's about it - not tested. It does include the DMA changes that should make WinCE games more stable but I make no guarantees.
It's still using old GD code which means (with the DMA changes I've made) it will most likely break Street Fighter Alpha and some other games.
Use the supplied plugins and Maple.ini to get vibration support and use F12 menu to enable VMU LCD overlay. Also, make sure to change sorting mode because it defaults to "Alternate" which turned out not to work for some games.
This release goes beyond experimental, it's downright partisan :) I'm not kiding you - unless you like 'em rough stay clear. I'd like to have some feedback on vibration support for upcoming T10 and that's the only reason it exists.

PS. No changes to full-screen mode in this one, and no support for 16:X aspect ratios. And Yuki, stick to your T9/3 for now :)

UPDATE 2: Okay people, here's what you need to have vibration:
1) T9/3 or T9/4 Makaron executable
2) T9/5 or T9/6 MakaronPAD.dll
3) Maple.ini edited so that MakaronPAD is being loaded instead of MakaronVMU for Slot 1 or Slot 2 on given port
4) Gamepad capable of vibration
5) Game with PuruPuru Pack support (you might still need to enable it in game options)

If you can't get T9/4 to run at all with supplied Maple.ini (crashes with an error), but it does work if you modify it to have VMU (or nothing) instead of MakaronPAD in the Slot1/2, it's a problem with my code not doing the right thing with your pad. Another easy way to check is to use Maple.ini (and plugins too if nothing else helps) from T9/2.
If it does run but you get no FF effects it could be the game doesn't use it or needs to have it enabled first. If you're positive everything is as it should be, it's probably my code again. A fast way to test if the plugin is loaded as it should be:

HOLLY/Maple: 0x20: Makaron controller (0x00270101 / 0x00540905)
HOLLY/Maple: 0x01: Makaron VMU (0x00030201 / 0x00540904)
HOLLY/Maple: 0x02: Makaron controller (0x00270101 / 0x00540905)
HOLLY/Maple: 0x60: Makaron controller (0x00270101 / 0x00540905)
HOLLY/Maple: 0x41: Makaron VMU (0x00030201 / 0x00540904)
HOLLY/Maple: 0x42: Makaron VMU (0x00030201 / 0x00540904)

See, the 0x02 address of port A is using PAD plugin instead of VMU.
BTW, don't try to be too smart and have 2 VMUs and a PuruPuru Pack together. Though it's possible to assign addresses 0x04, 0x08 and 0x10, no real Dreamcast device has more then 2 slots and most games will not recognize such configuration. You can try your luck with homebrew KOS/Linux/BSD software, those usually don't have such limitations.
For those of you who never had a DC controller in their hands - PPP will fit in Slot 1 but it's big and will prevent you from using VMU in Slot 2. Not to mention only Slot 1 VMU LCD is visible (in Makaron too) so it's best to stick PPP into Slot 2.

And another thing - you'd be suprised how broken gamepad drivers can be. I've got two and each had it's nasty suprises (and I've yet to try PS2 Dualshock USB interface). Also, force feedback features can vary from very basic "rumble" ones to a real force working against your moves. It's not that simple to get those more complicated gamepads to do simple vibration it seems...

Source: http://dknute.livejournal.com/18911.html