1) Requirements

The minimum requirements for a PC to run Makaron (at all) are:

  * Intel Pentium 2 processor or compatible
  * Graphics card with full Shader Model 1.0 support (that is, Verex Shader 1.1 & Pixel Shader 1.4)
  * Windows XP SP2 / 32-bit
  * DirectX 9.0c
  * 128MB of free RAM
  * 25MB of free hard disk space

Makaron should run just fine on Windows 2000 SP4. Windows 9x/ME, Vista or 64-bit operating systems have not been tested.
Multi-CPU systems are highly recommended, please use the MT (multi threaded) version of emulator on those. As a rule of thumb, two slower CPUs/cores are better then one fast. Right now will not benefit from having more than 2 physical CPUs, but perhaps in future... By the way, HT (Hyper-Threading) technology found in Pentium 4 series is NOT the same as having multiple cores. Not to mention Makaron doesn't like NetBurst architecture much.

To actually use the emulator you'll also need:

* Dreamcast ROM image set
* DirectX-compatible gamepad

Any gamepad will do, but unless it has at least a directional pad, one analog stick and 7 buttons, you will not be able to map all of Dreamcast controller functions.
The ROM set is BIOS and FLASH memory images, dumped from your Dreamcast into binary files. There are ways and tools for getting these, whether or not legal depends on the laws of the place you live in. Keep that in mind.

You need only one ROM set, but since Dreamcast games were region-locked, to play games from different regions than your own you must have other sets as well. There are three in total - one for each respective region: Asia (JP), Americas (USA) and Europe/Australia (EU).
Put the files in the ROM folder and give them proper names, that is BIOS_xx.bin and FLASH_xx.bin, where xx is the region short handle, JP, USA or EU.
In Japan (all Asia?) there were three different revisions of the ROM. The earliest one seems to be flawed, and the last one removes support for bootable CDs. Do not use them.

Proper FLASH files are very important, as many so-called USA/JP ones are just EU hacks. Dreamcast stores user preferences in the FLASH area, along with last valid RTC settings. Most emulators therefore overwrite those files with updated values (just as Dreamcast does). You can suspect your FLASH file is invalid/damaged when:
- NTSC BIOS (orange swirl logo) sets 50Hz refresh rate, instead of 60Hz
- You are being asked to set up current date/time every time you run emulator
- Date/time can be set, but emulator hangs every time trying to boot a game
- BIOS does not boot GDI images specified for that region

Note that it is perfectly normal for Dreamcast (and therefore Makaron) to ask for date/time again after it has not been used for more then a month or so. More on this below.
DevBox ROM (BIOS revision 1.011) set is also supported to some degree. The region code for the files is DEV. There's not much use for it, but it does have different swirl animation :)

If you get missing DirectX DLLs errors, you need to install newer version of DX9c runtime. Go visit Microsoft homepage.

2) GD-ROM images

The only way for Makaron to emulate CD/GD media is to use image file(s). The supported formats are CDI and GDI, and the CDI has to be self-bootable type. Some CDI images are unreadable under Windows but will boot in Dreamcast - those will do fine.
GDI images will require proper ROM files and region settings or will not boot (well, duh).
Once Makaron is started you can't 'change' the emulated CD/GD media, since there is no user interface that would allow you to do so.
Actually, ISO format is supported as well, but since it's not bootable it's of no use to anyone but me. ISO or non self-bootable CDI will simply make Makaron enter CD-Player in BIOS.

Windows CE based games and programs will not work as there is no MMU support (yet?). Those crash the emulator just after SEGA logo.
Some pirated games have broken or otherwise nasty loaders that will crash Makaron. Don't expect that to be fixed. Use GDI rips of the discs you own to play.

3) Configuration

The main window menu is a stub and doesn't work. All settings are to be made in the INI files before the executable is run.
Unless you know what you're doing, stick to defaults and SH4 recompiler. Available MMX/SSE extensions will be used to improve speed and accuracy of the emulator. 
As long as the PVR window is the active one, F12 key will show/hide a simple menu. In this menu you can try and tweak few graphics settings, but keep in mind those will revert to defaults every time Makaron is restarted.
You can exit Makaron running in full screen mode by pressing ALT+F4 (you might need to press it twice).

Certain JP/USA titles will hang with a black screen or crash Makaron right after SEGA logo. It appears these get confused by RGB video cable. Switch to composite in the INI file and that will work. There is no difference between RGB and composite video out on Makaron.
Pirated versions of those titles might have it reversed and will not work with composite video cable, but will work with RGB. Go figure :)

If you get date/time setup window every time you run Makaron, follow this procedure:
- ignore the window that pops up after swirl logo, simply accept to close it
- enter BIOS menu
- enter console configuration
- choose time & date setting option
- once the window opens just close it by accepting, do not make any changes (make sure the time doesn't advance a minute at that particular moment - if it does, redo this step)
- leave to main BIOS menu
- close Makaron

This will store valid time into the FLASH file. Unless it's read-only file or is corrupted :)
You cannot set Makaron's realtime clock to any arbitrary time you wish. It's disabled for now. Makaron will use your PC local time for Dreamcast RTC.

Makaron does not change Windows registry. To remove it, simple delete all the files.

4) Maple plugins

I'll make this short & simple:
* edit Makaron.ini and set "PADcfg = 1" (in [Settings] section)
* run Makaron, select and set up your game pad
* before you run Makaron again, set "PADcfg = 0"

You can map analog (pressure-sensitive) buttons/triggers to L & R. If your pad is some sort of all-analog type and you can't get it to work properly (on L/R or other buttons) drop me a note. I might be able to fix that with some feedback.
If you map digital buttons to analog triggers L & R, check the "digital" option as well. This will make the plugin report full press rather then half-way one on them.
Check "SEGA" for games that tend to ignore non-standard pads, equipped with C & Z buttons. This will prevent the plugin from reporting their existence (though if assigned, C & Z will return valid values when pressed).

Obviously, virtual controller device can't be configured. It's there to add more VMUs and unassign pads from ports.

Anything else you want, you'll need to figure it out yourself. Force feedback is not yet supported, as is keyboard or mouse. And no, you can't use plugins from other emulators.

x) Known problems

Well, there are tons of bugs and missing functionality :)
Remember, this is work in progress.
