Makaron Test 9/1
--

Here's Makaron Test 9/1. The main purpose of this release it to fix some issues T9 had, but there are other changes as well.
Firstly there's the new AEG code in AICA - not entierly correct mind you, but it will get better in time. I belive I've explained it enough before but just to be sure: It makes AICA module somewhat slower. Nothing is free you know. It should be offset by ARM7 code being recompiled this time.
Second major change is the addition of fog processing. You will need at least Pixel Shader 2.0 for this to work, and it better be fast (worst case scenario, that is palletized & filtered texture with fog and color clamping, is 9 textures lookups + some 50 other instructions per pixel).
This also causes Makaron to lag a bit at startup now, as it has to recreate some 200 PS programs to cover all possible cases.

I tried not to touch SH4 code much, but I did change how HOLLY handles DMA transfers. This might break quite a number of things but was necessary to fix couple of games. Mostly CAPCOM ones, go figure. Some people out there should really learn how to use DMA... There are games that start the DMA and assume it's going to finish before the program advances to the point where it has to use the transferred data - without actually checking that. The easiest way around this problem is to complete the transfers the moment they are started - but of course there are other games that get confused by immediate end-of-transfer interrupt, or miss it, and hang. Yet other games require that the transfer at least advances a bit once started, or the unchaged counter will make them think it's already done. All this is also very timing-related, might work or not depending how fast the emulator goes and when the interrupts actually arrive. Not funny.
I solved this by forcing DMA transfers to take time to finish - just like on the real hardware. The difference is a DMA in progress will slow SH4 (because it's blocking memory bus or HOLLY) and Makaron doesn't account for that. Not to mention I can't exactly check for interrupts every instruction, like SH4, as this would kill performance. I came up with timings that should work well on both slow and fast systems - but it might still need some tweaking.

As a side effect you now get to experience loading times. Just like on your good old Dreamcast. Yay! :) So be patient when staring at blank or "Please wait" / "Now loading" screens. I know this feature will not get good press but I like it. So it stays :)
By the way, fixes to DMA engine (although not timing-related) made "Soul Calibur" and "Dead or Alive 2" dialogs re-appear.

Emulation speed/statistics information is no longer displayed. If you want it, re-enable it in F12 menu.

On a special request from Yuki I've looked into MakaronPAD plugin. It is now possible to assign normal digital buttons to POV directional pad. The plugin version has been bumped up - not a big deal, but it won't work in T8/T9 unless you hex-edit it. You shouldn't be using those anymore :)

Enough Makaron for this year. Silmeria still needs to be rescued and I want some strong monsters to test out triple Nibelung Valesti combo (Hrist->Lenneth->Alicia) :]

Source: http://dknute.livejournal.com/14862.html