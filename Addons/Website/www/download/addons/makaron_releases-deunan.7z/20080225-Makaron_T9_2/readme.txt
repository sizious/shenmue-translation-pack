Makaron Test 9/2
--

Here's Makaron Test 9/2 with MMU support in recompiler.
If you have any problems with it, go back to T9/1. This version is pretty broken (lots of unfinished modifications) but I want to know how badly :)
Again, too many changes to list. Some bug fixes (to SH4 recompiler as well). PAD plugin now enforces 5% dead zone in analog stick center position - this should cure "cursor keeps running away" problem in some games. New AICA/ARM code (back to interpreter for now) sounds much better, no DSP yet. More messages will now appear in English, in future it will be possible to support many languages (via translation files or something like that).

There's new system of identifying GD-ROMs and MIL-CDs - it's main purpose is to enable MMU where necessary. The database is far from complete though, so some GDs will not be recognized. Please report those, but do make sure to provide proper title, MD5 sum computed by Makaron, region, and whether it is Windows CE game or normal one. DO NOT REPORT PIRATED SOFTWARE. I will ignore/delete such reports on sight. Same goes for dubious ones, with spelling errors and such.
If you happen to stumble upon WinCE game that is not recognized you'll need to enable MMU manualy in the ini file. And let me repeat that again - MMU requires a damn fast CPU. 2,4GHz Core2 Duo is the absolute minimum - the faster the better.

The multi-threaded GD reading is not yet finished. You might want to enable it anyway, see GDROM.ini for that, but be advised that some games will refuse to boot or hang with this option enabled. Most should work.

UPDATE 2: Oops. Last minute changes to GD detection code broke it completly. Sorry :) I've posted revised T9/2 so please redownload.

Source: http://dknute.livejournal.com/16732.html