Makaron T12/3
--

Back to the business at hand - apparently this blog started to attract the wrong type of crowd. Teen angst and/or stupidity I can deal with but I'm not sure if I should keep tolerating comments that are clearly meant to be abusive (to me or to other people). For now I'll just change my policy on deleting comments. If that doesn't help, there are other methods I have at my disposal.
Pity, but I guess in any large enough group of people there's bound to be an idiot or two.

Oh, and I can't seem to get this point across: No, you can't have analog controls mapped to keyboard. Period.
That said, inputs will not work in some games on T12 series, and this includes Power Stone, Zombie Revenge and Crazy Taxi, to name a few. Yes, I could hack around it but I see little point in doing so. These problems should hopefully be gone in next major release. Also, keep in mind these are arcade games and often work with dedicated controls that are not easily emulated.

BTW, I fixed some problems and added more games again so I just might release another version soon. Watch this space.


UPDATE: I just found this serial port log sitting on my hard drive. Try to guess which game it came from (don't let the text fool you, it's from NAOMI):

Nindows2 for DREAMCAST version 2.12
(C) SEGA ENTERPRISES SYSTEM R&D Library Team
Startup SCIF 115200 BPS Buffer[1024Byte] 

HEAP INITIALIZE
  Address = $8dc16140
  Size    = $00027c00


UPDATE 2: As promised, here's an update. I bumped the version number to T12/3 to avoid confusion. Runs few more games, has detection code for plain images (though those will not work if the protection cannot be emulated). Get it while it's still there :)
Oh, and you can't exactly play Crazy Taxi right now but there's always the Dreamcast version. Many people don't realize you can get much better shadows in that game with Z-fail #2 method (set in F11 menu).

Source: http://dknute.livejournal.com/31480.html