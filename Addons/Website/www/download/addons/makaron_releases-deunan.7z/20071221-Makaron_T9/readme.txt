Makaron Test 9
--

Here is Makaron Test 9 for your pleasure. There are lots of internal changes, but nothing revolutionary - so don't expect it to be much better/faster compared to earlier versions. From user point of view, it's almost the same as T8. Quite frankly the only reason I'm releasing it is to test some new stuff inside. For example, it's only thanks to user input that I found the NVidia FX series cards bug so fast (and actually it affected all cards, just that FX couldn't cope with it at all).
There are also people out there who simply have to test anything new that is released, because they love emulating stuff. So this is like a small gift for them, to enjoy for few moments before the novelty wears off :)

Like I said, there are tons of small (and not so small) internal changes to the emulation engine. Some of this stuff is so new it wasn't even tested much yet, so expect bugs. If you find a game that doesn't work now and it used to, please drop me a note - I'd like to find and fix the regressions first.
I won't go into much detail, but here's a list of things I consider interesting enough to explain a bit:

Dynamic Z-buffer range compression
This is a new method of dealing with overblown Z/W values. Most of the work is done in vertex shader so there should be no noticable speed impact. I mean, if there is then your graphics card was too slow to begin with and this is just another drop in the bucket.
Now I can handle geometry more like PVR2 does, which is good because this allows proper shadow casting. Very much like NANs, infinities are now detected and handled CPU-side - so far it appears to work as expected. All this and no Z-precision issuses, not that I'm aware of at least. Unless there's a game out there making a real use of 32-bit floating point HDR in Z-buffer this might just be THE solution :)
Note: There are games that still do not render properly due to other bugs, also this does nothing to cure transparency/ordering problems.

Shader Model 2 is now default
Makaron will now use VS 2.0 and PS 2.x (x being 0, a or b - where available), and fall back to 1.1/1.4 if it has to. What's more, I might be dropping SM1 support sometime in future. There are so many problems with it... I've had VS 1.1 break geometry which VS 2.0 handled just fine. And let me remind you again that palletized textures filtering is disabled on PS 1.4 beacuse it's too primitive for that kind of processing.
It's also about features that older cards do not have - like multiple render targets, or floating-point type surfaces. The Z compression code is considerably shorter compiled for 2.0 profile than it is for 1.1 by the way. Funny thing though, even if SM3 code is shorter it actually executes slower on most cards. That and the bugs I found in the drivers made me choose SM2 as the best perfomer.

Texture caching fixed
At least I hope it is :) Makaron MT version should no longer crash so much or trash textures. That does mean the single-threaded version will be a bit slower though - it's a tradeoff I've made to allow for proper locking. Some bugs still remain, mostly to be seen in Soul Calibur, but that's another story.

Shadows now work
Well, most of the time, and so are enabled by default. There are several ways it can be done - so far I was unable to come up with one method capable of handling all cases. Maybe there isn't one... Well, for now you can switch between different algorithms - you'll need to do that for Crazy Taxi series at least.

You really should be using multiple-core system for Makaron, mind you - this is the target PC I'm aiming for. SH4 speed is very important, but once you can do rendering in parallel most games will happily run full-speed on as little as 70-100MIPS. Seeing as AthlonXP clocked at 2000MHz is just below the required minimum, I'd say any mid-level X2 or C2D system will do fine.

The known bugs you will surely ecounter are mostly in AICA (sound module) code. The volume levels are still wrong - not sure why, I made the tables up to the specs. And yet PCM range often exceeds 16-bit, causing major distortions even if clipped. Also, ARM speed has been reduced to 1.5MIPS - this should make Soul Reaver happy. This is not exactly correct either, and will probably break some other games... I'll keep looking for a better solution.

As usuall, if there are any silly-yet-critical bugs discovered, I'll fix them right away. Other ones will have to wait for next "major" release :P

WARNING! Be careful not to overwrite your VMU or INI files when moving to T9!

Source: http://dknute.livejournal.com/14314.html