Makaron Test 8/3
--

Bug in MakaronPAD 0.T.7.2 confirmed - you can't assign A, B & START buttons.
I already fixed that and here is the update. Unpack and replace, that's all.

Remember, you can enable basic shadow handling in F12 menu - it just a hack but works with some games (Soul Calibur, Virtua Fighter, ...)

And one more thing (apparently not all of you had a real Dreamcast): I've included memory card files preloaded with some saves and A1 is almost full. You can either:
* delete those files, MakaronVMU will create new ones (you need to format those in BIOS, just as with any new memory card on real hardware)
* format the existing cards in BIOS to clear them out, or simply delete few saves from them
* unpack empty and pre-formatted card images I've included in the 7z file named "Clean VMUs for dummies.7z" :]

Source: http://dknute.livejournal.com/11188.html
