

				BINHACK32 (Linux Version)
		     Compiled with g++ 4.4.3 under Ubuntu 10.04 LTS


	IP.BIN/BOOT.BIN SB Hacker - 32bit BINHACK Clone - FamilyGuy 2010

	This is my attemp at creating a clone of binhack.exe in a 32-bit executable
	format to be compatible with non-16bit operating system (aka 64bit Win7).
	The Goal is to make it a *clone* so it can be used the same way as the
	original, just rename it BINHACK.EXE and it should works with old batch
	files. It'll also enable the VGA flag in the ip.bin, as there's no good
	reason not to do so.

	A big thank you goes to SiZiOuS for optimizing and cleaning my source code!

	FamilyGuy 2010
