______________________________________________

 GDI Explorer - v1.3.1.2
			by japanese_cake, 2010
______________________________________________


[+] What is GDI Explorer?
    ~~~~~~~~~~~~~~~~~~~~~
    
	GDI Explorer is a small tool that enables you to extract data
	from *.gdi files. It works with both NAOMI and DREAMCAST images.

	Features:
	 - Browse Dreamcast and Naomi GDI files
	 - Extract files (IP and IP0000 too)
	 - Generate "sorttxt.txt" file for mkisofs ("mkisofs [params] -sort sorttxt.txt")
	 - convert GD-DA (raw audio tracks) to CD-DA
	 - Decrypt Naomi binary (you may need naomi PIC DES key: http://guru.mameworld.info/naomi/index.html)
	 - Create CUE file for mounting images in a virtual drive.


	If you have any ideas for features or improvements, you're welcome!

	DotNet framework 3.5 is required.


[+] THANKS:
    ~~~~~~~~

 - Deunan from http://dknute.livejournal.com for his help concerning DES decryption.


[+] NOTES
    ~~~~~~~~

 - In some game ISOs, there are filenames ending by a dot ".". After extraction, those filenames
   don't have this dot anymore. If someone knows a trick to put a dot at the end of filenames,
   please send me a email.

   Example: in "Skies of Arcadia" ISOs, the file "DISK1." will be named "DISK" after extraction.


[+] TODO:
    ~~~~~~~~

 - Command line support.
 - Converting GDDA from an external file
 - Preparation command in order to make a autoboot game easier.
 - Improve exception managment.
 - Clean up GDI Lib and UI code.
 - Drag & drop to desktop for file extraction and GDDA conversion.
 - Localization support.
 - CRC/MD5/SHA1 checksums support.
 - any ideas ?


[+] History:
    ~~~~~~~~

v1.3.0.1 - beta to v1.3.1.2 (2010/09/08) :
 - Fixed: Some loading errors.
 - Fixed: Clean up GDIUtils.
 - Fixed: Create a folder "trackXX" while extracting a data track.
 - Added: Open a save dialog box while extrating a file.
 - Added: Auto-paste PIC DES key if presents in the clipboard.

v1.2 to v1.3.0.1 - beta (2010/09/07) :
 - Fixed: Less memory consumption while extracting files
 - Fixed: Clean up some parts of my code.
 - Fixed: Dont count directories in session information frame.
 - Fixed: Dont highlight Naomi bootfile in file list.
 - Fixed: Crash while converting CDDA if no one has been found in a session.
 - Added: Ask for a prefix while generating "sorttxt.txt" file (default "data\").
 - Added: Can decrypt a Naomi binary (need a PIC DES key per game) from
	  an external file or from a file inside a GDI game.


v1.1.3 to v1.2 (2010/07/04) :
 - Removed: GDI2CUE Converter (not really useful ?!).
 - Added: Columns sorting in the list view.
 - Added: Now when extracting session 1 and 2, it extracts bootstrap ("IP.BIN") too.
 - Added: File loading improvements.
 - Added: GDDA to CDDA conversion (using the tree view or conversion menu).
 - Added: Highlight bootfile in file list.
 - Added: CUE file export.

v1.1.2 to v1.1.3 (2010/06/11) :
 - Fixed: After extraction, some files got corrupted.
 - Fixed: Disc tree navigation don't show the current opened directory.
 - Added: Now shows GDDA tracks too.
 - Added: Drag & drop with .gdi files.

v1.1 fixed to v1.1.2 (2010/03/11) :
 - Added: IP.BIN & IP0000.BIN extraction.
 - Added: Messagebox after extracting boot file or sorttxt.txt file.
 - Added: newer version of GDI2CUE Converter (v1.3.0.1).

v1.1 to v1.1 fixed (2010/03/04):
 - Fixed: cannot extract multiple files.
 - Fixed: association button crashes programs.
 - Fixed: unhandled WinForms exceptions.
 - Added: sorttxt.txt file generation.
 - Added: gdi icon when gdi files are associated with GDI Explorer.
 - Added: new explorer icons.

v1.0b to v1.1 (2010/02/20):
 - Improved: exception handling.
 - Fixed: file access date.
 - Fixed: extracting process failed when an app is reading a file/dir.
 - Fixed: extracting progress-bar doesn't count correctly.
 - Added: loading window.
 - Added: list multiple selection.
 - Added: you can now associate *.gdi files with GDI Explorer.
 - Bonus: I made a GDI icon for those who need it.

v1.0b :
 - First public beta

______________________________________________

http://japanese-cake.livejournal.com/
______________________________________________
