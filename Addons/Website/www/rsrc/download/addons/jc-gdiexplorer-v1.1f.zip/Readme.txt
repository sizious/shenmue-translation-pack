______________________________________________

 GDI Explorer - v1.1 Fixed
			by japanese_cake, 2010
______________________________________________


[+] What is GDI Explorer?
    ~~~~~~~~~~~~~~~~~~~~~
    
	GDI Explorer is a small tool that enables you to extract data
from *.gdi files. It works with both NAOMI and DREAMCAST image. It also can
generate sorttxt.txt file for mkisofs ("mkisofs [params] -sort sorttxt.txt").

	Dotnet framework 3.5 is required.

[+] History:
    ~~~~~~~~

v1.1 to v1.1 fixed (04/03/2010):
 - Fixed: cannot extract multiple files.
 - Fixed: association button crashes programs.
 - Fixed: unhandled WinForms exceptions.
 - Added: sorttxt.txt file generation.
 - Added: gdi icon when gdi files are associated with GDI Explorer.
 - Added: new explorer icons.

    
v1.0b to v1.1 (20/02/2010):

 - Improved: exception handling.
 - Fixed: file access date.
 - Fixed: extracting process failed when an app is reading a file/dir.
 - Fixed: extracting progress-bar doesn't count correctly.
 - Added: loading window
 - Added: list multiple selection.
 - Added: you can now associate *.gdi files with GDI Explorer.
 
 - Bonus: I made a GDI icon for those who need it.

v1.0b :
 - First public beta

______________________________________________

http://japanese-cake.livejournal.com/
______________________________________________
