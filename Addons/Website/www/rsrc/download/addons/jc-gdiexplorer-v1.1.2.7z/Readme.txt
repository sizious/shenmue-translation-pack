______________________________________________

 GDI Explorer - v1.1.2
			by japanese_cake, 2010
______________________________________________


[+] What is GDI Explorer?
    ~~~~~~~~~~~~~~~~~~~~~
    
	GDI Explorer is a small tool that enables you to extract data
from *.gdi files. It works with both NAOMI and DREAMCAST image. It also can
generate sorttxt.txt file for mkisofs ("mkisofs [params] -sort sorttxt.txt").

	DotNet framework 3.5 is required

[+] History:
    ~~~~~~~~

v1.1 fixed to v1.1.2 (2010/03/11) :
 - Added: IP.BIN & IP0000.BIN extraction
 - Added: Messagebox after extracting boot file or sorttxt.txt file.
 - Added: newer version of GDI2CUE Converter (v1.3.0.1)

v1.1 to v1.1 fixed (2010/03/04):
 - Fixed: cannot extract multiple files.
 - Fixed: association button crashes programs.
 - Fixed: unhandled WinForms exceptions.
 - Added: sorttxt.txt file generation.
 - Added: gdi icon when gdi files are associated with GDI Explorer.
 - Added: new explorer icons.

    
v1.0b to v1.1 (2010/02/20):

 - Improved: exception handling.
 - Fixed: file access date.
 - Fixed: extracting process failed when an app is reading a file/dir.
 - Fixed: extracting progress-bar doesn't count correctly.
 - Added: loading window
 - Added: list multiple selection.
 - Added: you can now associate *.gdi files with GDI Explorer.
 
 - Bonus: I made a GDI icon for those who need it.

v1.0b :
 - First public beta

______________________________________________

http://japanese-cake.livejournal.com/
______________________________________________
