______________________________________________

 GDI Explorer - v1.2
			by japanese_cake, 2010
______________________________________________


[+] What is GDI Explorer?
    ~~~~~~~~~~~~~~~~~~~~~
    
	GDI Explorer is a small tool that enables you to extract data
from *.gdi files. It works with both NAOMI and DREAMCAST image. It also can
generate sorttxt.txt file for mkisofs ("mkisofs [params] -sort sorttxt.txt"),
convert GD-DA (raw audio tracks) to CD-DA, and create CUE file for those who
need it.

	If you have any ideas for features or improvements, you're welcome!

	DotNet framework 3.5 is required


[+] TODO:
    ~~~~~~~~

 - Drag & drop to desktop for file extraction and GDDA conversion.
 - Localization support.
 - CRC/MD5/SHA1 checksums support.
 - any ideas ?


[+] History:
    ~~~~~~~~

v1.1.3 to v1.2 (2010/07/04) :
 - Removed: GDI2CUE Converter (not really useful ?!).
 - Added: Columns sorting in the list view.
 - Added: Now when extracting session 1 and 2, it extracts bootstrap ("IP.BIN") too.
 - Added: File loading improvements.
 - Added: GDDA to CDDA conversion (using the tree view or conversion menu).
 - Added: Highlight bootfile in file list.
 - Added: CUE file export.

v1.1.2 to v1.1.3 (2010/06/11) :
 - Fixed: After extraction, some files got corrupted.
 - Fixed: Disc tree navigation don't show the current opened directory.
 - Added: Now shows GDDA tracks too.
 - Added: Drag & drop with .gdi files.

v1.1 fixed to v1.1.2 (2010/03/11) :
 - Added: IP.BIN & IP0000.BIN extraction.
 - Added: Messagebox after extracting boot file or sorttxt.txt file.
 - Added: newer version of GDI2CUE Converter (v1.3.0.1).

v1.1 to v1.1 fixed (2010/03/04):
 - Fixed: cannot extract multiple files.
 - Fixed: association button crashes programs.
 - Fixed: unhandled WinForms exceptions.
 - Added: sorttxt.txt file generation.
 - Added: gdi icon when gdi files are associated with GDI Explorer.
 - Added: new explorer icons.

v1.0b to v1.1 (2010/02/20):
 - Improved: exception handling.
 - Fixed: file access date.
 - Fixed: extracting process failed when an app is reading a file/dir.
 - Fixed: extracting progress-bar doesn't count correctly.
 - Added: loading window.
 - Added: list multiple selection.
 - Added: you can now associate *.gdi files with GDI Explorer.
 - Bonus: I made a GDI icon for those who need it.

v1.0b :
 - First public beta

______________________________________________

http://japanese-cake.livejournal.com/
______________________________________________
