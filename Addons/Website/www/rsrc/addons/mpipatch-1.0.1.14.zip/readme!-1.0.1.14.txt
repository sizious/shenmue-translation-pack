+--------------------------------------------+
| Shenmue MAPINFO.BIN Patcher (console ed.)  |
| (C) 2004 whiteShadow. All rights reserved. |
+-----------------------+--------------------+--------------------------+
|			| http://ws-soft.ma.cx/smod/mpipatch.htm (n/ay) |
|			+-----------------------------------------------+
|									|
+------------------------+------+					|
| README!.TXT			|					|
| Lamest readme I ever wrote :/ |					|
+-------------------------------+     +---------------------------------+
|				      | Development time		|
|				      | Start: Friday 29, January, 2004 |
|				      | End: Sunday 01, February, 2004  |
|				      +---------------------------------+ 
|									|
|	READ THIS FILE THOROUGHLY !BEFORE! USING THE PROGRAM		|
|									|
# --------------------------------------------------------------------- #
# PURPOSE OF THE PROGRAM #						|
|									|
| Quickly patch a map information file with data from other map		|
| information file, for map switching.					|
|									|
# --------------------------------------------------------------------- #
# FOREWARNING! #							|
|									|
| Even though it is not marked as so, this program is in ALPHA state.	|
| I have NOT tested the program's behaviour in non-standard situations,	|
| so if you DO use it, please follow ALL the instructions BY THE LETTER.|
|									|
| Take particular care with the -n switch because there are parsing bugs|
| for SURE with it, and I cannot predict what will happen if you pass	|
| it an invalid filename or the name of an existing file - it will	|
| probably just fail silently, but you should be warned:		|
|									|
| !!!!! RESPECT THE PARAMETER ORDER!					|
|									|
| Do not do this for example:						|
|									|
|	mpipatch.exe (file1) (file2) -n -d (newfile)			|
|									|
| Or this:								|
|									|
|	mpipatch.exe (file1) (file2) (newfile) -n			|
|									|
| For the set of switches, check the section below called INSTRUCTIONS.	|
|									|
| If you follow the right order and use correct filenames, there should	|
| be no problems. Oh, for long filenames with spaces, enclose the	|
| filename in double quotes, like so:					|
|									|
|	mpipatch.exe "my map info 1.bin" "my map info 2.bin"		|
|									|
| :)									|
|									|
| Also, you CAN use relative file paths, for example, if your current	|
| directory is C:\SHENMUE\DISC3\DIR1 and you want to patch the		|
| MAPINFO.BIN in that dir with a MAPINFO.BIN in C:\SHENMUE\DISC3\DIR4,	|
| you can use:								|
|									|
|	mpipatch.exe mapinfo.bin ..\DIR4\MAPINFO.BIN			|
|									|
| I haven't properly tested for double quote-related behaviour when	|
| using relative paths, so be careful with directories with spaces in	|
| their names. There shouldn't be any spaces in ANY names in the game	|
| (hell, I KNOW there AREN'T), but you're warned. :)			|
|									|
| So the bottomline is, take care when using this program, and BACKUP	|
| your original MAPINFO.BIN files - the program will do it automaticaly	|
| by copying the original file to MAPINFO.BIN.BAK, but if the file	|
| already exists it WILL NOT back it up and give you an error message,	|
| which you can safely ignore, unless you really wanted that backup.	|
|									|
| And now you ask: "Then why did you release this program when it's so	|
| buggy?" The answer is quite simple actually: I need this program for	|
| myself, and because it is only meant to simplify ONE already simple	|
| task I think it is a waste of time to try to make it perfect. :)	|
| Blame me for wanting to share it... I could have kept it for myself.	|
|									|
# ---------------------------------------------------------------------	#
# INSTRUCTIONS #							|
|									|
| Program usage:							|
|									|
|	mpipatch.exe (file1) (file2) (switches)				|
|									|
|	This will load both files, scan them for the ECAM header, then	|
|	copy the data from file 2 into file 1. The file is overwritten.	|
|	To create a new file instead, add the -n switch to the command	|
|	line, like this:						|
|									|
|	mpipatch.exe (file1) (file2) -n (newfile)			|
|									|
|	You MUST specify all 3 file names if you use the -n switch.	|
|	Otherwise the program will fail with the message:		|
|									|
|	"ERROR!: CANNOT SAVE TO FILE:"					|
|									|
| Available switches:							|
|									|
|	-? or -h	: show help page				|
|	-n		: create new file; no overwrite			|
|	-d		: delete file 2 after patching file 1		|
|			  (not recommended)				|
|	-v		: verbose; show progress messages		|
|									|
| Interactive mode:							|
|									|
|	The program can run in 'interactive' mode, that is, you can	|
|	simply start it and it will ask you for the 2 MAPINFO.BIN	|
|	files for patching. In this mode, however, you can not use	|
|	the switches. Maybe a later version, if I feel like it.		|
|									|
# ---------------------------------------------------------------------	#
# REQUESTS/BUG REPORTS #						|
|									|
| Feel free to report a bug to me, but do not contact me with		|
| suggestions. I wrote this utility for myself and very simple uses.	|
| I will not waste any more of my time with it.				|
|									|
# --------------------------------------------------------------------- #
# DISCLAIMER #								|
|									|
| This program is provided as-is without warranty of ANY kind. NO	|
| guarantees are made as to the quality and readyness of the program	|
| in any situation whatsoever.						|
|									|
| The program has been tested, but it is impossible to predict how it	|
| will behave on certain configurations.				|
|									|
| Use this program at your own risk.					|
|									|
+-----------------------------------------------------------------------+

				Your favorite Shenmue freak, whiteShadow.
#EOF