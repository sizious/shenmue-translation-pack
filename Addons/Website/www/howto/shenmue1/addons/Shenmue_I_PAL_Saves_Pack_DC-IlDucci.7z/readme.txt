Shenmue_I_PAL_Saves_Pack_DC-IlDucci
---

Disco1-AntesDeCharlie � Disc 1, before the QTE against Charlie.
Disco1BarMJQYHeartbeats � Disc 1, when you have to check the MJQ Bar and later the Heartbeats bar when searching for sailors.
Shenmue1-Disco1ResumeBarMJQYHeartbeats.7z � Disc 1, Resume file related to previous file.
Shenmue1-Disco1ResumeQTECharlie.7z � Disc 1, Resume file before the QTE against Charlie.
Shenmue1-Disco2AgenciasViajesHastaInicioDisco3.7z � Disc 2, Search for Travel Agencys until Disc 3�s Start File.
Shenmue1-Disco2Feria-InicioInfiltraci�nVDA.7z � Disc 2, Harbor (With the start of the infiltration secquence on the Old Warehouse District).
Shenmue1-Disco2Hasta2�VisitaChen.7z � Disc 2, All the Phoenix Mirror quests until you see Chen for the second time.
Shenmue1-Disco3-EntrenaCarretillasYTrabajoDias1y2.7z � Disc 3, Day when you do the forklift training, Work days 1 and 2.
Shenmue1-Disco3-FinalYJuegoTerminado2.7z � Disc 3, final sections before End Game, plus a Finished Game save.
Shenmue1-Disco3-TrabajoDias67NozomiY8Despido.7z � Disc 3, days 6 and 7 (Nozomi�s kidnap), 8 (Fired from work, start of the 70 man battle).
Shenmue1-Disco3TrabajoDias345.7z � Disc 3, Work days 3, 4 and 5 (One of these days is one day delayed)
Shenmue1-EDITResumeGuiZhangDisco3.7z � Disc 3, Resume File contains a Move Training from Gui Zhang.
Shenmue1-EDITResumeNozomiLlorando.7z � Disc 3, Resume File contains the Nozomi Crying cutscene on Sakuragaoka (Modified so it�s snowy).
Shenmue1-EDITResumeQTEMotosCharlie.7z � Disc 3, Resume File contains the QTE when three bikers try to gangbang Ryo.
Shenmue1-Iniciodeljuego-VMI.7z � Disc 1, Game start (So you don�t need to see the death of Iwao)
Shenmue1-InicioDisco1YFinalDisco3EnResume.7z � Disc 1 Start and Resume File contains the end of disc 3.
Shenmue1-InicioDisco2-FinalDisco1.7z � Disc 1�s final steps, Start of Disc 2.
Shenmue1-JuegoCompletadoFinalJuegoyUltimoDia.7z � Ending File and Last game day.
Shenmue1-SaveInicioDiscos23Final1.7z � Start File for Discs 2 and 3, End of Disc 1. (Or Ending at all?)