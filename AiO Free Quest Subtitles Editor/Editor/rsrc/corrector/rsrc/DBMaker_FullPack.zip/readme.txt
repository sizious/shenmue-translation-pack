HOW TO COMPILE A DATABASE FOR THE NPC EDITOR
############################################

1-  Compile then copy the datasgen executable here in the pack root
2-  Extract every files from HUMANS.AFS in the PKS directory, for each DISC, with AFS Explorer
3-  Compile the movepks file and move the movepks binary in the PKS directory where is located every PKS file
4-  Run the movepks file. A lot of FULL_AFS_FILE_DUMP_* directory will be created, with x PKS files inside of each of them
5-  Do the same for each disc, after that, you can delete the movepks binary.
6-  in each DISC directory, edit the datasgen batch file. set the NUM_DIRS variable with the correct value, 
    corresponding of each FULL_AFS_FILE_DUMP_* previously generated
7-  Edit the config.cmd file with appropriate values
8-  Run the init_DB batch
9-  Run the make_DB batch and wait. see the output.log file for details
10- Compress the directory DB created with 7-zip:
    - Archive format: 7z
    - Compression level: Ultra
    - Compression method: LZMA
    - Dictionnary size: 64 MB
    - Words size: 273
    - Solid block size: 64 GB


