1-Extract each FREE??.AFS in the FREE?? directory.
2-Copy the sortfree binary in each FREE?? directory and run it.
  A lot of DIR?? directories will be created, and each *.SRF
  will be kept in the FREE?? directory root.
3-Launch the rename.cmd (WORKAROUND FOR WINDOWS BUG IN THE DIR 
  COMMAND)
4-Copy the MakeDB.exe binary in this directory
5-Run the srfscript.cmd, and wait.
6-Compress with 7zip the srfscript.xml and rename it to 
  srfscript.db
7-Copy it in the data directory of the Free Quest tool.
8-Done.