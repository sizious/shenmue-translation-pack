
      ..::  B R E A K I N G   T H E   L A N G U A G E   B A R R I E R ::..
                 _______________________________________________
                //           /     //    /           /          \
               //     //____/     //    /    //     /           /
              //_____      /     _     /    //_____/   ___     /
             //    //     /     //    /          _//    //    /
            //__________.//____//___.//_________/_/____//___./
                / \__     __________  __________  ___________
               /     \   //         \/          \/           \
              /    _./  //   ___    //          /      /    //
             /    /____//   /  /___//    ___   //     /    //
            /          \   /      //    //    //    _/    //
            \_________./__/      //____//___./\_________.//
                                      |  S H E N T R A D  |
 __                            ________________________________________________
 __| SHENMUE TRANSLATION PACK |________________________________________________
 
 This package was made with Shenmue Release Maker, part of the Shenmue 
 Translation Pack.
 __           _________________________________________________________________
 __| CREDiTS |_________________________________________________________________
 
  Founder / Coder................: Manic
  Coder / Additional tools.......: [big_fury]SiZiOUS (sbibuilder.shorturl.com)
  Alpha/Beta test................: Shendream, Sadako, Hiei-, Kogami-san, ...
  Thanks flying to...............: To everyone supporting us.       
  URL............................: http://shenmuesubs.sourceforge.net/     
 _____________________________________________________________________[ EOF ]___