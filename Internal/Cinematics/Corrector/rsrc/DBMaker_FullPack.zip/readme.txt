HOW TO COMPILE A DATABASE FOR THE SRF EDITOR
############################################

1-  Compile then copy the datasgen executable here in the pack root
2-  Extract every SRF files from each AFS located in the STREAM directory for each disc with AFS Explorer.
    Copy them in the corresponding 0* directory ("DISC1" -> "01"). You'll have a lot of SRF files in each
    0* folders.
3-  Edit the makedb.vbs file to match your config 
4-  Run the makedb.vbs script and wait. see the output.log file for details
5-  Compress the directory DB created with 7-zip:
    - Archive format: 7z
    - Compression level: Ultra
    - Compression method: LZMA
    - Dictionnary size: 64 MB
    - Words size: 273
    - Solid block size: 64 GB


