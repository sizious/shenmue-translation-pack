HOW TO COMPILE A DATABASE FOR THE SRF EDITOR
############################################

1-  Compile then copy the datasgen and movesrf executables here in the pack root
2-  Extract every SRF files from each AFS located in the STREAM directory for each disc with AFS Explorer.
    Copy them in the corresponding DISC*\SRF directory.
3-  Configure the config.cmd batch file matching your game config.
4-  Run the init_DB.cmd batch file. A lot of DIR_* directory will be created, with x SRF files inside of each of them
5-  in each DISC directory, edit the datasgen batch file. set the NUM_DIRS variable with the correct value, 
    corresponding of each DIR_* previously generated
6-  Run the make_DB batch and wait. see the output.log file for details
7-  Compress the directory DB created with 7-zip:
    - Archive format: 7z
    - Compression level: Ultra
    - Compression method: LZMA
    - Dictionnary size: 64 MB
    - Words size: 273
    - Solid block size: 64 GB


